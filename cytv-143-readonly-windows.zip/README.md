# Windows diagnostic for issue #143

This check reads the saved Root removal and observes what webOS reports about
the screen on your LG 55UN8060PVB. It sends two one-time foreground queries and
reads the existing recovery records. SSH sign-in and filesystem reads may
appear in system logs or access times. The check leaves the TV's apps,
settings, Home routing and recovery records in place.

## Run the check

1. Use the same Windows PC and Windows account you used for Clean Your TV.
   Extract the complete diagnostic ZIP to a new folder. Open PowerShell in
   that folder. Keep the TV on and on the same network. Run while no installer
   operation is running and, if possible, while LG Home is already visible
   during normal use. Leave the TV screen as it is during the check.
2. Run these commands in PowerShell. They use Python 3.12 and install the SSH
   dependency in a virtual environment inside the extracted folder.

   ```powershell
   py -3.12 -m venv .venv
   .\.venv\Scripts\python.exe -m pip install -r requirements-issue-143.txt
   .\.venv\Scripts\python.exe -B .\scripts\issue-143-readonly.py
   ```

   If Windows has Python 3.12 but the `py` launcher is missing, use
   `python -m venv .venv` as the first command. Continue only if each setup
   command succeeds. The check automatically selects the one saved Root
   connection with a pending full removal and verifies the TV's existing SSH
   host key. If prompted in PowerShell, enter your usual Root SSH password or
   the passphrase for your saved SSH key. PowerShell hides the input.
3. Send only the generated `cytv-143-readonly.json` to the maintainer through
   the channel you agreed on. In your message, say whether LG Home, Live TV or
   another screen was visible during the check. No screenshots are needed.
   Share the JSON even if its status is anything other than `read`. If Python
   setup fails before a JSON file appears, tell the maintainer which command
   failed.

The JSON contains fixed categories for the removal stage, routing evidence and
foreground replies. It excludes passwords, keys, addresses, local paths,
operation IDs and app inventories. The report records a diagnostic observation.
The maintainer will use it to decide which recovery procedure applies to this
installation.
