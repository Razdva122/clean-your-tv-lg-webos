"""Bounded original-stream observation for new Developer Mode operations.

The imported PROGRAM is bundled with Python on desktop and Android. A trusted
invocation verifies retained bytes; status never executes the retained worker.
An unresolved claim is permanent uncertainty, never permission to resubmit.
"""
import hashlib
import base64
import json
import re
import shlex
import time
import uuid

from .outcomes import START_HELPER
from .package import SCREENSAVER_APP, SCREENSAVER_IPK
from .errors import (UserError, LocalRecoveryError, TVCommandError, TV_STORAGE_FULL, no_root_observer_details,
                     OBSERVER_EXCEPTION_NAMES, OBSERVER_EXCEPTION_CODES, OBSERVER_REASONS,
                     OBSERVER_FILESYSTEM_OPERATIONS)

PROTOCOL = 'no-root-original-stream-v1'
ROOT = '/tmp/.cytv-installer'
JAIL_ROOT = '/.cytv-installer'
PUBLIC_ROOT = '/media/developer/temp'
ROOT_SSH_PRIVATE = '/tmp/.cytv-installer-root'
ROOT_SSH_PUBLIC = '/var/lib/clean-your-tv-installer'
ROOT_SSH_DISK = ROOT_SSH_PUBLIC + '/private'
APPS = ('com.local.nativehome', 'com.gathin.tvhome')

# Read-only selection before pending. Never rediscover a root for recovery.
STORAGE_SELECT = r'''
(function(){
'use strict';
var fs=require('fs'),path=require('path'),input=JSON.parse(process.argv[process.argv.length-1]);
var root=input.root,uid=process.getuid();
function present(name){try{fs.lstatSync(name);return true;}catch(e){if(e.code==='ENOENT')return false;throw e;}}
var legacy=present(root),jail=present(input.alternate_root);
if(legacy&&jail)throw Error('foreign-reservation');
if(!legacy){
 var parent=fs.lstatSync(path.dirname(input.alternate_root));
 var safe=uid!==0&&parent.isDirectory()&&!parent.isSymbolicLink()&&parent.uid===uid&&
    (parent.mode&448)===448&&!(parent.mode&18);
 if(jail&&!safe)throw Error('unsafe-directory');
 if(safe)root=input.alternate_root;
}
process.stdout.write(JSON.stringify({operation:input.plan.operation,root:root}));
}());
'''

PROGRAM = r'''
(function () {
'use strict';
var fs=require('fs'), path=require('path'), c=require('constants'), crypto=require('crypto');
var cp=require('child_process'), Decoder=require('string_decoder').StringDecoder;
var input=JSON.parse(process.argv[process.argv.length-1]), plan=input.plan;
var uid=process.getuid(), root=input.root, publicRoot=input.public_root;
process.umask(63); // Private by default, including the sender's inherited environment.
var protocol='no-root-original-stream-v1', apps=['com.local.nativehome','com.gathin.tvhome'];
function fail(code){throw Error(code);}
function hash(raw){return crypto.createHash('sha256').update(raw).digest('hex');}
function buffer(raw){return new Buffer(raw,'utf8');}
function canonical(value){
 if(value===null||typeof value!=='object')return JSON.stringify(value);
 if(Array.isArray(value))return '['+value.map(canonical).join(',')+']';
 return '{'+Object.keys(value).sort().map(function(k){return JSON.stringify(k)+':'+canonical(value[k]);}).join(',')+'}';
}
function same(a,b){return a.dev===b.dev&&a.ino===b.ino;}
function exists(name){try{fs.lstatSync(name);return true;}catch(e){if(e.code==='ENOENT')return false;throw e;}}
function directory(name,privateLeaf,sdk){
 var s=fs.lstatSync(name);
 if(!s.isDirectory()||s.isSymbolicLink()||(s.uid!==0&&s.uid!==uid))fail('unsafe-directory');
 // A root-owned sticky temporary ancestor is safe for an owned private child.
 // SDK staging is a vendor-owned shared namespace, not private evidence.
 var sdkParent=sdk&&s.uid===0&&((name===publicRoot&&(s.mode&4095)===511)||
     (name==='/media/developer'&&[509,511].indexOf(s.mode&4095)>=0));
 if((s.mode&18)&&!(s.uid===0&&(s.mode&512))&&!sdkParent)fail('writable-directory');
 if(privateLeaf&&(s.uid!==uid||(s.mode&511)!==448))fail('nonprivate-directory');
 return s;
}
function ancestry(name,publicAccess){
 var current=path.resolve(name);
 for(;;){var s=directory(current,false,publicAccess);if(publicAccess&&!(s.mode&1))fail('private-public-parent');var parent=path.dirname(current);if(parent===current)break;current=parent;}
}
function sync(name){var fd=fs.openSync(name,c.O_RDONLY|c.O_NOFOLLOW);try{fs.fsyncSync(fd);}finally{fs.closeSync(fd);}}
function mkdir(name,mode){
 fs.mkdirSync(name,448);var before=fs.lstatSync(name),fd=fs.openSync(name,c.O_RDONLY|c.O_NOFOLLOW);
 try{if(!same(before,fs.fstatSync(fd)))fail('changed-directory');fs.fchmodSync(fd,mode);fs.fsyncSync(fd);}
 finally{fs.closeSync(fd);}sync(path.dirname(name));
}
function read(name,limit,publicFile){
 ancestry(path.dirname(name),publicFile);
 var before=fs.lstatSync(name), fd, raw;
 if(!before.isFile()||before.isSymbolicLink()||before.nlink!==1||before.uid!==uid||
    (before.mode&511)!==(publicFile?420:384)||before.size>limit)fail('unsafe-file');
 fd=fs.openSync(name,c.O_RDONLY|c.O_NOFOLLOW|c.O_NONBLOCK);
 try{
  if(!same(before,fs.fstatSync(fd)))fail('changed-file');
  raw=new Buffer(before.size);var offset=0;
  while(offset<raw.length){var n=fs.readSync(fd,raw,offset,raw.length-offset,offset);if(n<=0)fail('short-read');offset+=n;}
  var after=fs.fstatSync(fd);
  if(!same(before,after)||after.size!==before.size||!same(before,fs.lstatSync(name)))fail('changed-file');
 }finally{fs.closeSync(fd);}
 return raw;
}
function json(name){return JSON.parse(read(name,262144,false).toString('utf8'));}
function exclusive(name,raw,mode){
 var fd=fs.openSync(name,c.O_WRONLY|c.O_CREAT|c.O_EXCL|c.O_NOFOLLOW,mode||384);
 try{var b=buffer(raw),offset=0;while(offset<b.length){var n=fs.writeSync(fd,b,offset,b.length-offset);if(n<=0)fail('short-write');offset+=n;}fs.fsyncSync(fd);}
 finally{fs.closeSync(fd);}
 sync(path.dirname(name));
}
function atomicNew(name,value){
 var tmp=path.dirname(name)+'/.pending-'+crypto.randomBytes(16).toString('hex');
 exclusive(tmp,canonical(value));
 // Exclusive link publishes complete bytes without replacing first evidence.
 try{fs.linkSync(tmp,name);}finally{fs.unlinkSync(tmp);}
 sync(path.dirname(name));
}
if(typeof c.O_NOFOLLOW!=='number'||typeof c.O_EXCL!=='number')fail('unsupported-storage');
if(!plan||plan.protocol!==protocol||plan.edition!=='no-root'||!/^\w{32}$/.test(plan.operation)||
   !/^[a-f0-9]{32}$/.test(plan.operation)||!/^[a-f0-9]{32}$/.test(plan.diagnostic_id)||
   (plan.action!=='install'&&plan.action!=='remove')||!Array.isArray(plan.slots)||plan.slots.length!==2||
   root!==path.resolve(root)||publicRoot!==path.resolve(publicRoot)||!/^[a-f0-9]{64}$/.test(plan.source_sha256)||
   !/^[a-f0-9]{64}$/.test(plan.configuration_sha256))fail('invalid-plan');
var op=plan.operation, opdir=root+'/operations/'+op, stage=publicRoot+'/cytv-'+op;
var planText=canonical(plan), planSha=hash(planText), active=root+'/active', marker='owner-'+op+'.json';
plan.slots.forEach(function(slot,i){
 var request={id:apps[i],subscribe:true};
 if(plan.action==='install')request.ipkUrl=stage+'/'+(i===0?'helper.ipk':'launcher.ipk');
 if(slot.app!==apps[i]||slot.index!==i||slot.method!=='com.webos.appInstallService/dev/'+plan.action||
    slot.request!==canonical(request)||slot.request_sha256!==hash(slot.request)||
    (plan.action==='install'?(!/^[a-f0-9]{64}$/.test(slot.artifact_sha256)||typeof slot.version!=='string'):
       (slot.artifact_sha256!==null||slot.version!==null)))fail('invalid-slot');
});
function binding(){return {protocol:protocol,operation:op,plan_sha256:planSha,source_sha256:plan.source_sha256};}
function bound(value){var expected=binding();Object.keys(expected).forEach(function(k){if(!value||value[k]!==expected[k])fail('foreign-evidence');});return value;}
function checked(){
 ancestry(root);directory(root,true);directory(root+'/operations',true);directory(opdir,true);
 if(read(opdir+'/plan.json',262144,false).toString('utf8')!==planText||hash(read(opdir+'/observer.js',262144,false))!==plan.source_sha256)fail('changed-plan-source');
 bound(json(opdir+'/storage.json'));
 return bound(json(opdir+'/prepared.json'));
}
function publicStage(){
 ancestry(publicRoot,true);var s=directory(stage,false),identity=bound(json(opdir+'/public-stage.json'));
 if(s.uid!==uid||(s.mode&511)!==493||s.dev!==identity.dev||s.ino!==identity.ino)fail('changed-public-stage');
}
function stateDirectory(name){
 var leaf;
 function owner(s){return s.uid===uid||s.uid===5999&&s.gid===5000;}
 for(var current=name;;current=path.dirname(current)){
  var s=fs.lstatSync(current);if(!s.isDirectory()||s.isSymbolicLink())fail('unsafe-state-parent');
  if(current===name&&(!owner(s)||(s.mode&2)))fail('unsafe-state-owner');
  if(current===name)leaf=s;
  if(current===path.dirname(current))break;
 }
 ['ssap-key.json','apps.json'].forEach(function(child){
  var file=name+'/'+child;if(!exists(file))return;var s=fs.lstatSync(file);
  if(!s.isFile()||s.nlink!==1||!owner(s)||(s.mode&2)||(child==='ssap-key.json'&&(s.mode&7)))fail('unsafe-config-file');
 });
 return leaf;
}
function upload(){
 attached();var proof=input.proof||{},isArtifact=input.command==='upload-artifact',destination,name,digest,mode,pinned;
 if(isArtifact){
  var index=slotIndex();if(plan.action!=='install')fail('invalid-upload');
  publicStage();destination=stage;name=index===0?'helper.ipk':'launcher.ipk';
  digest=plan.slots[index].artifact_sha256;mode=420;pinned=fs.lstatSync(destination);
 }else{
  var claim=evidence('files','config-claim');
  if(plan.action!=='install'||!claim||claim.nonce!==proof.nonce||configState('files')!=='unknown'||
     !proof.hashes||Object.keys(proof.hashes).sort().join(',')!=='apps.json,ssap-key.json'||
     hash(canonical(proof.hashes))!==plan.configuration_sha256||
     ['apps.json','ssap-key.json'].indexOf(proof.name)<0||typeof proof.directory!=='string'||
     proof.directory!==path.resolve(proof.directory))fail('invalid-configuration-upload');
  destination=proof.directory;name=proof.name;digest=proof.hashes[name];mode=name==='ssap-key.json'?416:420;
  pinned=stateDirectory(destination);
 }
 // Cwd pins the verified directory inode. All writes below are relative: a
 // rename/symlink substitution of its old path cannot redirect private bytes.
 process.chdir(destination);
 var entered=isArtifact?fs.statSync('.'):stateDirectory('.');
 if(!same(pinned,entered))fail('changed-upload-directory');
 var tmp='.cytv-'+crypto.randomBytes(16).toString('hex'),fd=fs.openSync(tmp,c.O_WRONLY|c.O_CREAT|c.O_EXCL|c.O_NOFOLLOW,384);
 var size=0,digestStream=crypto.createHash('sha256'),finished=false;
 function cleanup(){if(fd!==null){fs.closeSync(fd);fd=null;}if(exists(tmp))fs.unlinkSync(tmp);}
 function abort(error){if(finished)return;finished=true;clearTimeout(timer);cleanup();throw error;}
 var timer=setTimeout(function(){abort(Error('upload-timeout'));},90000);
 process.stdin.on('data',function(chunk){
  try{
   size+=chunk.length;if(size>(isArtifact?128*1024*1024:4*1024*1024))fail('upload-too-large');digestStream.update(chunk);
   for(var offset=0;offset<chunk.length;){var n=fs.writeSync(fd,chunk,offset,chunk.length-offset);if(n<=0)fail('short-write');offset+=n;}
  }catch(e){abort(e);}
 });
 process.stdin.on('error',abort);
 process.stdin.on('end',function(){
  try{
   if(digestStream.digest('hex')!==digest)fail('changed-upload');
   fs.fchmodSync(fd,mode);fs.fsyncSync(fd);fs.closeSync(fd);fd=null;
   attached();
   if(isArtifact){
    publicStage();if(!same(pinned,fs.lstatSync(destination)))fail('changed-upload-directory');
    if(!exists(name)){
     if(exists(claimName(index)))fail('claimed-artifact-missing');
     try{fs.linkSync(tmp,name);}catch(e){if(e.code!=='EEXIST')throw e;}
    }
    // A delayed host can verify an already published archive, never replace it.
    fs.unlinkSync(tmp);
    if(hash(read(destination+'/'+name,128*1024*1024,true))!==digest)fail('changed-artifact');
   }else{
    if(!same(pinned,stateDirectory(destination)))fail('changed-upload-directory');
    stateDirectory('.');fs.renameSync(tmp,name);
   }
   sync('.');finished=true;clearTimeout(timer);process.stdout.write(JSON.stringify({operation:op}));
  }catch(e){abort(e);}
 });
 // Give legacy libuv a loop turn to register the pipe before waiting for I/O.
 setImmediate(function(){process.stdin.resume();});
}
function attached(){
 var identity=checked(), s=directory(active,true), owner=bound(json(active+'/'+marker));
 if(s.dev!==identity.dev||s.ino!==identity.ino||owner.nonce!==identity.nonce||fs.readdirSync(active).join(',')!==marker)fail('foreign-reservation');
 return identity;
}
function claimName(i){return opdir+'/claim-'+i+'.json';}
function evidence(i,kind){
 var name=opdir+'/'+kind+'-'+i+'.json';if(!exists(name))return null;
 var value=bound(json(name));if(value.slot!==i)fail('foreign-slot');return value;
}
function slotStatus(i){
 var claim=evidence(i,'claim'), terminal=evidence(i,'terminal'), readback=evidence(i,'readback');
 if(terminal&&(!claim||claim.disposition!=='request'||['success','failure'].indexOf(terminal.terminal)<0))fail('invalid-terminal');
 if(terminal){
  var reply=terminal.reply,detail=reply&&reply.details,state=detail&&detail.state;
  if(!reply||typeof reply!=='object'||Array.isArray(reply))fail('invalid-terminal-reply');
  var negative=reply.returnValue===false||Object.prototype.hasOwnProperty.call(reply,'errorCode')||
      detail&&Object.prototype.hasOwnProperty.call(detail,'errorCode')||/fail|error/.test(state||'');
  if(terminal.terminal==='success'&&(negative||[plan.action==='install'?'installed':'removed','success'].indexOf(state)<0)||
     terminal.terminal==='failure'&&!negative&&Object.keys(reply).length)fail('conflicting-terminal');
 }
 if(readback&&(!claim||!(terminal&&terminal.terminal==='success'||claim.disposition==='no-request')||readback.result!=='matches'))fail('invalid-readback');
 if(claim&&['request','no-request'].indexOf(claim.disposition)<0)fail('invalid-claim');
 return {submission:claim?(claim.disposition==='no-request'?'sealed':'claimed-possibly-submitted'):'prepared',
         terminal:terminal?terminal.terminal:'none',readback:readback?'matches':'not-checked',
         reason:(evidence(i,'lost')||{}).reason||null,reply:terminal?terminal.reply||{}:{}};
}
function accepted(i){var s=slotStatus(i);return !s.reason&&s.readback==='matches'&&(s.terminal==='success'||s.submission==='sealed');}
function stabilize(i){
 slotStatus(i);['claim','terminal','readback'].forEach(function(kind){var name=opdir+'/'+kind+'-'+i+'.json';if(exists(name))sync(name);});sync(opdir);
}
function predecessor(i){for(var k=0;k<i;k++){if(!accepted(k))fail('predecessor-unverified');stabilize(k);}}
var configSteps=plan.action==='install'?['files','eim','launch']:['restore'];
function configState(step){
 var claim=evidence(step,'config-claim'),result=evidence(step,'config-result');
 if(claim&&!/^[a-f0-9]{64}$/.test(claim.nonce))fail('invalid-configuration-claim');
 if(result&&(!claim||result.nonce!==claim.nonce||['verified','unavailable'].indexOf(result.result)<0||result.result==='unavailable'&&step!=='eim'))fail('invalid-configuration-result');
 return result?'complete':claim?'unknown':'prepared';
}
function syncConfig(step){
 if(configState(step)!=='complete')fail('configuration-unverified');
 sync(opdir+'/config-claim-'+step+'.json');sync(opdir+'/config-result-'+step+'.json');sync(opdir);
}
function configSummary(){var value={};configSteps.forEach(function(step){value[step]=configState(step);});return value;}
function closed(){
 if(!exists(opdir+'/closed.json'))return null;
 var value=bound(json(opdir+'/closed.json'));if(value.result!=='verified')fail('invalid-closure');return value;
}
function reservation(){
 if(exists(opdir+'/closed.json'))return 'closed';
 try{attached();return 'active';}catch(e){
  if(exists(active)&&fs.readdirSync(active).length)return 'busy';
  if(exists(opdir+'/reservation')){
   var identity=checked(),s=directory(opdir+'/reservation',true),owner=bound(json(opdir+'/reservation/'+marker));
   if(s.dev===identity.dev&&s.ino===identity.ino&&owner.nonce===identity.nonce&&fs.readdirSync(opdir+'/reservation').join(',')===marker)return 'prepared';
  }
  return 'unknown';
 }
}
function status(){checked();return {protocol:protocol,operation:op,plan_sha256:planSha,reservation:reservation(),configuration:configSummary(),
 slots:plan.slots.map(function(s,i){return slotStatus(i);}),closed:closed()};}
function prepare(){
 ancestry(path.dirname(root));
 if(!exists(root))mkdir(root,448);directory(root,true);
 if(!exists(root+'/operations'))mkdir(root+'/operations',448);directory(root+'/operations',true);
 if(!exists(opdir)){
  mkdir(opdir,448); // Incomplete exclusive initialization is never repaired.
  if(typeof input.source!=='string'||hash(input.source)!==plan.source_sha256)fail('changed-source');
  exclusive(opdir+'/plan.json',planText);exclusive(opdir+'/observer.js',input.source);
  atomicNew(opdir+'/storage.json',binding()); // Prove atomic publication support before requests.
  mkdir(opdir+'/reservation',448);
  var owner=binding();owner.nonce=crypto.randomBytes(32).toString('hex');
  exclusive(opdir+'/reservation/'+marker,canonical(owner));sync(opdir+'/reservation');
  var s=directory(opdir+'/reservation',true);owner.dev=s.dev;owner.ino=s.ino;
  exclusive(opdir+'/prepared.json',canonical(owner));
 }
 var identity=checked();if(exists(opdir+'/closed.json'))fail('operation-closed');
 if(exists(opdir+'/reservation')){
  var source=directory(opdir+'/reservation',true), prepared=bound(json(opdir+'/reservation/'+marker));
  if(source.dev!==identity.dev||source.ino!==identity.ino||prepared.nonce!==identity.nonce||fs.readdirSync(opdir+'/reservation').join(',')!==marker)fail('changed-reservation');
  try{fs.renameSync(opdir+'/reservation',active);}catch(e){if(e.code!=='ENOENT')throw e;}
 }
 attached();sync(active);sync(opdir);sync(root);
 if(plan.action==='install'){
  ancestry(publicRoot,true);
  if(!exists(stage)){
   if(exists(opdir+'/public-stage.json'))fail('missing-public-stage');
   mkdir(stage,493);
   var created=directory(stage,false),stageIdentity=binding();stageIdentity.dev=created.dev;stageIdentity.ino=created.ino;
   exclusive(opdir+'/public-stage.json',canonical(stageIdentity));
  }
  publicStage();
 }
 return {operation:op,plan_sha256:planSha};
}
function storageCheck(){
 ancestry(path.dirname(root));
 if(!exists(root))mkdir(root,448);directory(root,true);
 if(exists(active)&&fs.readdirSync(active).length)fail('foreign-reservation');
 ancestry(publicRoot,true);
 // Exercise writes and durable publication before the host creates pending.
 // Names are exclusive; never clean another operation's files.
 var probe=root+'/.probe-'+op,link=probe+'.link',stageProbe=publicRoot+'/.cytv-probe-'+op;
 exclusive(probe,'probe');
 try{fs.linkSync(probe,link);sync(root);}finally{if(exists(link))fs.unlinkSync(link);fs.unlinkSync(probe);sync(root);}
 mkdir(stageProbe,493);fs.rmdirSync(stageProbe);sync(publicRoot);
 return {operation:op};
}
function slotIndex(){if(typeof input.slot!=='number'||input.slot%1||input.slot<0||input.slot>=plan.slots.length)fail('invalid-slot');return input.slot;}
function worker(i){
 attached();predecessor(i);
 if(plan.action==='remove')syncConfig('restore');
 if(exists(claimName(i))){slotStatus(i);return;}
 var slot=plan.slots[i];
 if(plan.action==='install'){publicStage();if(hash(read(JSON.parse(slot.request).ipkUrl,128*1024*1024,true))!==slot.artifact_sha256)fail('changed-artifact');}
 var claim=binding();claim.slot=i;claim.disposition='request';
 try{exclusive(claimName(i),canonical(claim));}catch(e){if(e.code==='EEXIST')return;throw e;}
 // No request before the permanent exclusive claim AND its directory sync.
 var child, timer, killer, done=false, total=0,count=0,text='',decoder=new Decoder('utf8'),stderr=0;
 function end(terminal,reason,reply){
  if(done)return;done=true;clearTimeout(timer);
  var result=binding();result.slot=i;
  try{if(terminal){result.terminal=terminal;result.reply=reply||{};atomicNew(opdir+'/terminal-'+i+'.json',result);}
      else{result.reason=reason;atomicNew(opdir+'/lost-'+i+'.json',result);}}
  catch(e){
   // Preserve an observed terminal separately from a journal durability failure.
   // If storage rejects even this marker, every later mutator must stabilize
   // the exact original evidence before it can advance to another slot.
   try{var lost=binding();lost.slot=i;lost.reason='terminal-persistence-unverified';atomicNew(opdir+'/lost-'+i+'.json',lost);}catch(ignored){}
  }
  // Keep stdin OPEN until the terminal file and containing directory are synced.
  if(child){
   child.stdin.end();child.kill();
   killer=setTimeout(function(){try{child.kill('SIGKILL');}catch(ignored){}},1000);
  }
 }
 function reply(value){
  if(!value||Array.isArray(value)||typeof value!=='object')return end(null,'malformed-reply');
  var details=value.details===undefined?{}:value.details;
  if(!details||Array.isArray(details)||typeof details!=='object')return end('failure');
  var state=String(details.state||'').toLowerCase();
  var projected={details:{state:['installing','installed','removing','removed','success','failed','error','install failed','remove failed'].indexOf(state)>=0?state:'unknown'}};
  function number(v){if(typeof v==='string'&&/^-?[0-9]{1,10}$/.test(v))v=Number(v);return typeof v==='number'&&v%1===0&&v>=-2147483648&&v<=2147483647?v:null;}
  ['errorCode','statusValue'].forEach(function(k){if(Object.prototype.hasOwnProperty.call(value,k))projected[k]=number(value[k]);});
  if(Object.prototype.hasOwnProperty.call(details,'errorCode'))projected.details.errorCode=number(details.errorCode);
  if(typeof value.returnValue==='boolean')projected.returnValue=value.returnValue;
  if(['FAILED_INTERNAL_ERROR','FAILED_CREATE_TMP','FAILED_NOT_ENOUGH_TEMP_SPACE','FAILED_NOT_ENOUGH_INSTALL_SPACE','FAILED_PACKAGEFILE_NOT_FOUND','FAILED_PACKAGEFILE_CORRUPT','FAILED_VERIFY','FAILED_IPKG_INSTALL','FAILED_INSTALL'].indexOf(details.reason)>=0)projected.details.reason=details.reason;
  if(value.returnValue===false||Object.prototype.hasOwnProperty.call(value,'errorCode')||
     Object.prototype.hasOwnProperty.call(details,'errorCode')||/fail|error/.test(state))return end('failure',null,projected);
  if(state===(plan.action==='install'?'installed':'removed')||state==='success')return end('success',null,projected);
 }
 function parse(chunk){
  if(done)return;total+=chunk.length;if(total>1048576)return end(null,'oversized-stream');
  text+=decoder.write(chunk);if(text.indexOf('\ufffd')>=0)return end(null,'malformed-utf8');
  while(!done){
   text=text.replace(/^\s+/,'');if(!text)return;if(text.charAt(0)!=='{')return end(null,'malformed-reply');
   var depth=0,quoted=false,escaped=false,stop=-1;
   for(var j=0;j<text.length;j++){
    var ch=text.charAt(j);
    if(quoted){if(escaped)escaped=false;else if(ch==='\\')escaped=true;else if(ch==='"')quoted=false;}
    else if(ch==='"')quoted=true;else if(ch==='{'||ch==='[')depth++;else if(ch==='}'||ch===']'){depth--;if(depth===0){stop=j+1;break;}}
   }
   if((stop<0?text.length:stop)>65536)return end(null,'oversized-reply');if(stop<0)return;
   var value;try{value=JSON.parse(text.slice(0,stop));}catch(e){return end(null,'malformed-reply');}
   text=text.slice(stop);count++;if(count>1024)return end(null,'too-many-replies');reply(value);
  }
 }
 timer=setTimeout(function(){end(null,'observation-timeout');},Math.min(input.timeout||150000,150000));
 try{
  child=cp.spawn(input.sender||'/usr/bin/luna-send-pub',['-i','luna://'+slot.method,slot.request],{stdio:['pipe','pipe','pipe']});
  child.stdin.on('error',function(){end(null,'sender-stdin-lost');});
  child.stdout.on('data',parse);
  child.stderr.on('data',function(chunk){stderr+=chunk.length;if(stderr>1048576)end(null,'oversized-stderr');});
  child.on('error',function(){end(null,'sender-unavailable');});
  child.on('close',function(){end(null,'stream-ended');clearTimeout(killer);});
 }catch(e){end(null,'sender-unavailable');}
}
function release(){
 checked();plan.slots.forEach(function(s,i){if(!accepted(i))fail('unresolved-slot');stabilize(i);});
 configSteps.forEach(syncConfig);
 var configuration=bound(json(opdir+'/configuration.json'));if(configuration.result!=='verified')fail('configuration-unverified');
 if(!exists(opdir+'/closed.json')){var close=binding();close.result='verified';atomicNew(opdir+'/closed.json',close);}
 else closed();
 sync(opdir+'/configuration.json');sync(opdir+'/closed.json');sync(opdir);
 // Only this exact old owner's child may be unlinked. A new nonempty active
 // directory cannot be removed by a delayed old rmdir (including duplicate releases).
 if(exists(active+'/'+marker)){
  var owner=bound(json(active+'/'+marker)),identity=checked();if(owner.nonce!==identity.nonce)fail('foreign-reservation');
  try{fs.unlinkSync(active+'/'+marker);sync(active);}catch(e){if(e.code!=='ENOENT')throw e;}
 }
 try{fs.rmdirSync(active);}catch(e){
  if(e.code!=='ENOENT'){
   if(['ENOTEMPTY','EEXIST'].indexOf(e.code)<0)throw e;
   try{
    var names=fs.readdirSync(active),current=directory(active,true);
    if(names.length!==1||!/^owner-[a-f0-9]{32}\.json$/.test(names[0])||names[0]===marker)fail('unexpected-reservation');
    var foreign=json(active+'/'+names[0]),foreignID=names[0].slice(6,-5),prepared=json(root+'/operations/'+foreignID+'/prepared.json');
    if(foreign.operation!==foreignID||foreign.protocol!==protocol||foreign.nonce!==prepared.nonce||
       foreign.plan_sha256!==prepared.plan_sha256||foreign.source_sha256!==prepared.source_sha256||
       current.dev!==prepared.dev||current.ino!==prepared.ino)fail('unexpected-reservation');
   }catch(changed){if(changed.code!=='ENOENT')throw changed;}
  }
 }
 sync(root);return status();
}
var result;
switch(input.command){
case 'storage-check':result=storageCheck();break;
case 'prepare':result=prepare();break;
case 'status':result=status();break;
case 'attach':attached();sync(active);sync(root);result={operation:op};break;
case 'upload-artifact':case 'upload-configuration':upload();return;
case 'artifacts':
 attached();publicStage();var missing=[];
 plan.slots.forEach(function(s,i){if(!exists(claimName(i))){var name=JSON.parse(s.request).ipkUrl;if(!exists(name))missing.push(i);else if(hash(read(name,128*1024*1024,true))!==s.artifact_sha256)fail('changed-artifact');}});
 result={operation:op,missing:missing};break;
case 'config-claim':
 attached();var step=input.slot,position=configSteps.indexOf(step);
 if(position<0)fail('invalid-configuration-step');
 if(plan.action==='install')plan.slots.forEach(function(s,i){if(!accepted(i))fail('unresolved-slot');stabilize(i);});
 configSteps.slice(0,position).forEach(syncConfig);
 var stateBefore=configState(step),won=false,token=null;
 if(stateBefore==='prepared'){
  var configClaim=binding();configClaim.slot=step;configClaim.nonce=crypto.randomBytes(32).toString('hex');
  try{exclusive(opdir+'/config-claim-'+step+'.json',canonical(configClaim));won=true;token=configClaim.nonce;}
  catch(e){if(e.code!=='EEXIST')throw e;}
 }
 if(configState(step)==='complete')syncConfig(step);
 result={operation:op,won:won,nonce:token,state:configState(step)};break;
case 'config-result':
 attached();var configStep=input.slot;
 if(configSteps.indexOf(configStep)<0)fail('invalid-configuration-step');
 var ownedClaim=evidence(configStep,'config-claim');
 if(!ownedClaim||!input.proof||input.proof.nonce!==ownedClaim.nonce||
    ['verified','unavailable'].indexOf(input.proof.result)<0||input.proof.result==='unavailable'&&configStep!=='eim')fail('foreign-configuration-result');
 if(configState(configStep)!=='complete'){
  var configResult=binding();configResult.slot=configStep;configResult.nonce=ownedClaim.nonce;configResult.result=input.proof.result;
  atomicNew(opdir+'/config-result-'+configStep+'.json',configResult);
 }
 syncConfig(configStep);result={operation:op};break;
case 'start':
 attached();var index=slotIndex();predecessor(index);
 if(!exists(claimName(index))){
  var workerInput={command:'worker',root:root,public_root:publicRoot,plan:plan,slot:index,sender:input.sender,timeout:input.timeout};
  var detached=cp.spawn(process.execPath,[opdir+'/observer.js',JSON.stringify(workerInput)],{detached:true,stdio:['ignore','ignore','ignore'],cwd:opdir});
  detached.unref();
 }
 result={operation:op};break;
case 'worker':worker(slotIndex());return;
case 'seal':
 attached();var sealIndex=slotIndex();predecessor(sealIndex);if(plan.action!=='remove')fail('invalid-seal');
 syncConfig('restore');
 var seal=binding();seal.slot=sealIndex;seal.disposition='no-request';exclusive(claimName(sealIndex),canonical(seal));result=status();break;
case 'readback':
 attached();var readIndex=slotIndex(), state=slotStatus(readIndex);
 if(state.reason||state.terminal!=='success'&&state.submission!=='sealed')fail('terminal-unverified');
 stabilize(readIndex);
 if(state.readback!=='matches'){var proof=binding();proof.slot=readIndex;proof.result='matches';atomicNew(opdir+'/readback-'+readIndex+'.json',proof);}
 result=status();break;
case 'configured':
 attached();plan.slots.forEach(function(s,i){if(!accepted(i))fail('unresolved-slot');stabilize(i);});
 configSteps.forEach(syncConfig);
 if(!exists(opdir+'/configuration.json')){var config=binding();config.result='verified';atomicNew(opdir+'/configuration.json',config);}
 else bound(json(opdir+'/configuration.json'));result=status();break;
case 'release':result=release();break;
case 'retire':
 checked();if(!closed())fail('operation-not-closed');
 if(plan.action==='install'&&exists(stage)){
  publicStage();
  plan.slots.forEach(function(s){var name=JSON.parse(s.request).ipkUrl;if(exists(name)){if(hash(read(name,128*1024*1024,true))!==s.artifact_sha256)fail('changed-artifact');fs.unlinkSync(name);sync(stage);}});
  fs.rmdirSync(stage);sync(publicRoot);
 }
 result=status();break;
default:fail('unsupported-command');
}
process.stdout.write(JSON.stringify(result));
}());
'''


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True)


# Keep the original Developer Mode program byte-for-byte: existing capsules
# authenticate it and must remain usable after the installer is updated.
ROOT_PROGRAM = PROGRAM.replace(
    'var uid=process.getuid(), root=input.root, publicRoot=input.public_root;',
    '''var uid=process.getuid(), root=input.root, publicRoot=input.public_root;
if(!plan||plan.connection!=='root-ssh'||uid!==0||root!=='/tmp/.cytv-installer-root'||publicRoot!=='/var/lib/clean-your-tv-installer'||input.sender!=='/usr/bin/luna-send')throw Error('invalid-plan');'''
).replace('function storageCheck(){', '''function storageCheck(){
 if(!exists(publicRoot)){ancestry(path.dirname(publicRoot));mkdir(publicRoot,493);}''').replace(
    'fs.fchmodSync(fd,mode);fs.fsyncSync(fd);fs.closeSync(fd);fd=null;',
    'if(!isArtifact){fs.fchownSync(fd,pinned.uid,pinned.gid);var owner=fs.fstatSync(fd);if(owner.uid!==pinned.uid||owner.gid!==pinned.gid)fail("unsafe-config-file");}fs.fchmodSync(fd,mode);fs.fsyncSync(fd);fs.closeSync(fd);fd=null;'
)


# This source is selected only by new plans bound to the fixed Helper state.
# Original Developer Mode and Root observer bytes remain valid for recovery.
PACKAGED_STATE_PROGRAM = PROGRAM.replace(
    "  if(current===name&&(!owner(s)||(s.mode&2)))fail('unsafe-state-owner');",
    """  var expanded=plan.configuration_directory===path.resolve(name)&&uid!==0&&
      s.uid===5999&&s.gid===5000&&(s.mode&4095)===511&&
      (process.getgid()===s.gid||process.getgroups().indexOf(s.gid)>=0);
  if(current===name&&(!owner(s)||(s.mode&2)&&!expanded))fail('unsafe-state-owner');"""
).replace(
    "  destination=proof.directory;name=proof.name;",
    """  if(proof.directory!==plan.configuration_directory)fail('invalid-configuration-upload');
  destination=proof.directory;name=proof.name;"""
).replace(
    ' fs.fchmodSync(fd,mode);fs.fsyncSync(fd);fs.closeSync(fd);fd=null;',
    """ var staged;
   if(!isArtifact){
    var file=fs.fstatSync(fd);
    if(file.gid!==pinned.gid)fs.fchownSync(fd,uid,pinned.gid);
    staged=fs.fstatSync(fd);
    if(!staged.isFile()||staged.nlink!==1||staged.uid!==uid||staged.gid!==pinned.gid)fail('unsafe-config-file');
   }
   fs.fchmodSync(fd,mode);fs.fsyncSync(fd);fs.closeSync(fd);fd=null;"""
).replace(
    "    stateDirectory('.');fs.renameSync(tmp,name);",
    """    if(!same(pinned,stateDirectory('.')))fail('changed-upload-directory');
    var source=fs.lstatSync(tmp);
    if(!same(staged,source)||source.uid!==uid||source.gid!==pinned.gid||
       source.nlink!==1||(source.mode&4095)!==mode)fail('unsafe-config-file');
    fs.renameSync(tmp,name);
    var published=fs.lstatSync(name);
    if(!same(staged,published)||published.uid!==uid||published.gid!==pinned.gid||
       published.nlink!==1||(published.mode&4095)!==mode||
       !same(pinned,stateDirectory(destination)))fail('unsafe-config-file');"""
)


def companion_source(program):
    # New three-package receipts have distinct source bytes. Keep the original
    # two-package program and each of its connection variants byte-for-byte.
    replacements = (
        ("apps=['com.local.nativehome','com.gathin.tvhome'];",
         "apps=['com.local.nativehome','com.gathin.tvhome','com.cleanyourtv.screensaver'];"
         "var packages=['helper.ipk','launcher.ipk','screensaver.ipk'];"),
        ("plan.slots.length!==2", "plan.slots.length!==apps.length"),
        ("(i===0?'helper.ipk':'launcher.ipk')", "packages[i]"),
        ("name=index===0?'helper.ipk':'launcher.ipk'", "name=packages[index]"),
    )
    for old, new in replacements:
        if program.count(old) != 1:
            raise ValueError('Unexpected No-root observer source')
        program = program.replace(old, new)
    return program


def source_for(root_ssh, private=None, configuration_directory=None, screensaver=False):
    # Existing capsules continue to authenticate the original source bytes.
    if root_ssh and private == ROOT_SSH_DISK:
        program = ROOT_PROGRAM.replace("root!=='/tmp/.cytv-installer-root'",
                                       "root!==plan.private_root||root!==" + canonical(ROOT_SSH_DISK))
    elif root_ssh:
        program = ROOT_PROGRAM
    else:
        program = PACKAGED_STATE_PROGRAM if configuration_directory is not None else PROGRAM
    return companion_source(program) if screensaver else program


def make_plan(operation, diagnostic_id, action, artifacts, versions, public_root=PUBLIC_ROOT, configuration_sha256=None, root_ssh=False, private_root=None, root_handoff=None, setup_start=None, configuration_directory=None):
    if root_ssh:
        public_root = ROOT_SSH_PUBLIC
    slots = []
    include_screensaver = action == 'install' and SCREENSAVER_IPK in artifacts
    components = list(zip(APPS, ('helper.ipk', 'launcher.ipk')))
    if include_screensaver:
        components.append((SCREENSAVER_APP, SCREENSAVER_IPK))
    for index, (app, name) in enumerate(components):
        request = {'id': app, 'subscribe': True}
        if action == 'install':
            request['ipkUrl'] = public_root + '/cytv-' + operation + '/' + name
        request = canonical(request)
        slots.append(dict(index=index, app=app, method='com.webos.appInstallService/dev/' + action,
                          request=request, request_sha256=hashlib.sha256(request.encode()).hexdigest(),
                          artifact_sha256=hashlib.sha256(artifacts[name]).hexdigest() if action == 'install' else None,
                          version=versions[app] if action == 'install' else None))
    plan = dict(protocol=PROTOCOL, edition='no-root', operation=operation, diagnostic_id=diagnostic_id,
                action=action, source_sha256=hashlib.sha256(source_for(root_ssh, private_root, configuration_directory, include_screensaver).encode()).hexdigest(), slots=slots,
                configuration_sha256=configuration_sha256 or hashlib.sha256(b'{}').hexdigest())
    if include_screensaver:
        plan['screensaver'] = True
    if root_ssh:
        plan['connection'] = 'root-ssh'
    if private_root is not None:
        if type(private_root) is not str or private_root not in ((ROOT_SSH_DISK,) if root_ssh else (ROOT, JAIL_ROOT)):
            refuse()
        plan['private_root'] = private_root
    if setup_start is not None:
        if (action != 'install' or type(setup_start) is not dict or set(setup_start) != {'generation'}
                or setup_start['generation'] is not None and not valid_generation(setup_start['generation'])):
            refuse()
        plan['setup_start'] = dict(setup_start)
    if configuration_directory is not None:
        from .operations import HELPER_STATE
        if root_ssh or configuration_directory != HELPER_STATE or setup_start != {'generation': None}:
            refuse()
        plan['configuration_directory'] = configuration_directory
    if root_handoff is not None:
        from .root_no_root_handoff import validate
        if not root_ssh or private_root is not None:refuse()
        plan['root_handoff']=validate(root_handoff)
    return plan


def private_root(plan):
    if plan.get('connection') == 'root-ssh':
        if 'private_root' not in plan:
            return ROOT_SSH_PRIVATE
        if plan['private_root'] != ROOT_SSH_DISK or 'root_handoff' in plan:
            refuse()
        return ROOT_SSH_DISK
    root = plan.get('private_root', ROOT)
    if type(root) is not str or root not in (ROOT, JAIL_ROOT):
        refuse()
    return root


def observation_error(command, failure, error=None, *, fresh_install=False, details=None):
    details = details if details is not None else no_root_observer_details({'command': command, 'failure': failure})
    # Preserve typed errors (including storage guidance and numeric SSH status),
    # while arbitrary transport exception messages stay private.
    if not isinstance(error, UserError):
        storage_preflight = fresh_install and command in ('storage-select', 'storage-check')
        reason = details.get('observer_reason')
        # Selection reports an unsafe parent only when the jail root already exists.
        reservation_conflict = (failure == 'foreign-operation' or reason == 'foreign-reservation'
                                or command == 'storage-select' and reason == 'unsafe-directory')
        if storage_preflight and not reservation_conflict:
            error = UserError('The TV storage check failed before any package request was sent.',
                              reason_code='storage-preflight-failed')
        else:
            error = UserError('The original No-root observation could not be verified. Recovery data was kept.',
                              reason_code='pending-operation')
    error.no_root_observer = details
    return error


def invoke(remote, plan, command, slot=None, source=None, proof=None, data=None, *, fresh_install=False,
           read_only_storage=False):
    def failure_error(failure, error=None, details=None):
        return observation_error(command, failure, error, fresh_install=fresh_install, details=details)

    request = dict(root=private_root(plan), public_root=PUBLIC_ROOT, plan=plan, command=command, slot=slot)
    if plan.get('connection') == 'root-ssh':
        if not getattr(remote, 'root', False):
            refuse()
        request.update(public_root=ROOT_SSH_PUBLIC, sender='/usr/bin/luna-send')
    program_source = source_for(plan.get('connection') == 'root-ssh', plan.get('private_root'),
                                plan.get('configuration_directory'), plan.get('screensaver') is True)
    if command == 'storage-select':
        if plan.get('connection') == 'root-ssh' or 'private_root' in plan:
            refuse()
        request['alternate_root'] = JAIL_ROOT
        program_source = STORAGE_SELECT
    if command == 'storage-inspect' or read_only_storage:
        if read_only_storage and command != 'storage-check':
            refuse()
        if command == 'storage-inspect' and (plan.get('connection') != 'root-ssh' or 'root_handoff' in plan):
            refuse()
        program_source = program_source.replace("case 'storage-check':result=storageCheck();break;", f"case '{command}':" + """
 if(plan.connection==='root-ssh'&&!exists(publicRoot))ancestry(path.dirname(publicRoot),true);
 else ancestry(publicRoot,true);
 if(exists(path.dirname(root)))ancestry(path.dirname(root));
 if(exists(root))directory(root,true);
 if(exists(active)){directory(active,true);if(fs.readdirSync(active).length)fail('foreign-reservation');}
 result={operation:op};break;""")
    if command == 'prepare':
        request['source'] = program_source if source is None else source
    if proof is not None:request['proof']=proof
    # The wrapper is not part of the source bound by a capsule. A diagnostic
    # envelope is always a failure, never a receipt.
    program = 'try {\n' + program_source + r"""
} catch (error) {
 function category(value, allowed) {return typeof value==='string'&&allowed.indexOf(value)>=0?value:'unknown';}
 var request=JSON.parse(process.argv[process.argv.length-1]);
 function storageArea(value) {
  if(typeof value!=='string'||value.charAt(0)!=='/')return 'unknown';
  var path=require('path'), name=path.resolve(value);
  var roots=[request.root,request.public_root], areas=['private-storage','public-staging'];
  for(var i=0;i<roots.length;i++){
   if(name===roots[i]||name.indexOf(roots[i]+'/')===0)return areas[i];
  }
  for(var j=0;j<roots.length;j++){
   for(var parent=path.dirname(roots[j]);;parent=path.dirname(parent)){
    if(name===parent)return 'storage-parent';
    if(parent===path.dirname(parent))break;
   }
  }
  return 'unknown';
 }
 process.stdout.write(JSON.stringify({operation:request.plan.operation,
  observer_error:{exception_name:category(error&&error.name,NAMES),
   exception_code:category(error&&error.code,CODES),observer_reason:category(error&&error.message,REASONS),
   filesystem_operation:category(error&&error.syscall,FILESYSTEM_OPERATIONS),storage_area:storageArea(error&&error.path)}}));
}
""".replace('NAMES', canonical(OBSERVER_EXCEPTION_NAMES)).replace('CODES', canonical(OBSERVER_EXCEPTION_CODES)).replace('REASONS', canonical(OBSERVER_REASONS)).replace('FILESYSTEM_OPERATIONS', canonical(OBSERVER_FILESYSTEM_OPERATIONS))
    try:
        # POSIX unset avoids depending on the TV env utility supporting -u.
        # The read-only check inspects directory metadata only. The writable
        # check and staging still use the native Root handoff lock when needed.
        if 'root_handoff' in plan and not read_only_storage:
            from .root_no_root_handoff import call
            loaded=getattr(remote,'_cytv_root_handoff_support',None)
            if not loaded:refuse()
            raw=call(remote,loaded,'storage' if command=='storage-check' else 'observer',
                     plan=plan,source=program_source,request=request,data=data)
        else:
            raw = remote.run('unset NODE_OPTIONS NODE_PATH && /usr/bin/node -e ' +
                             shlex.quote(program) + ' ' + shlex.quote(canonical(request)),
                             data=data, timeout=100 if data is not None else 30)
    except UnicodeError:
        raise failure_error('invalid-json') from None
    except (OSError, RuntimeError, ValueError, KeyError, TypeError) as error:
        failure = ('command-failed' if isinstance(error, TVCommandError) else
                   'timeout' if isinstance(error, TimeoutError) or getattr(error, 'reason_code', None) == 'operation-timeout' else
                   'connection-interrupted' if getattr(error, 'reason_code', None) == 'connection-interrupted' else
                   'transport-error')
        raise failure_error(failure, error) from None
    try:
        reply = json.loads(raw)
    except (ValueError, TypeError):
        raise failure_error('invalid-json') from None
    if not isinstance(reply, dict):
        raise failure_error('invalid-reply')
    if reply.get('operation') != plan['operation']:
        raise failure_error('foreign-operation')
    if 'observer_error' in reply:
        if type(reply['observer_error']) is not dict:
            raise failure_error('invalid-reply')
        details = no_root_observer_details(dict(reply['observer_error'], command=command, failure='observer-error'))
        storage_error = (UserError(TV_STORAGE_FULL, reason_code='tv-storage-full')
                         if details['exception_code'] in ('ENOSPC', 'EDQUOT') else None)
        raise failure_error('observer-error', storage_error, details)
    if command == 'storage-select' and reply.get('root') not in (ROOT, JAIL_ROOT):
        raise failure_error('invalid-reply')
    return reply


def refuse():
    raise UserError('The original No-root operation cannot safely continue. Recovery data was kept.',
                    reason_code='pending-operation')


def root_ssh_storage(installer, ramfs=False):
    legacy = shlex.quote(ROOT_SSH_PRIVATE)
    disk = shlex.quote(ROOT_SSH_DISK)
    command = f'''
if [ -e {legacy} ] || [ -L {legacy} ]; then
    printf CYTV_LEGACY_STORAGE
fi
if [ -e {disk} ] || [ -L {disk} ]; then
    printf CYTV_DISK_STORAGE
fi
'''
    layout = installer.remote.run(command).strip()
    if not ramfs and layout in ('', 'CYTV_LEGACY_STORAGE'):
        return None
    if layout in ('', 'CYTV_DISK_STORAGE') and not getattr(installer, '_root_handoff', None):
        return ROOT_SSH_DISK
    refuse()


def inspect_root_ssh_storage(installer, bundles, ramfs):
    selected = root_ssh_storage(installer, ramfs)
    versions = dict(zip(APPS, (installer.manifest['helper_version'], installer.manifest['home_version'])))
    if SCREENSAVER_IPK in bundles:
        versions[SCREENSAVER_APP] = installer.manifest['screensaver_version']
    plan = make_plan(uuid.uuid4().hex, uuid.uuid4().hex, 'install', bundles, versions,
                     root_ssh=True, private_root=selected)
    invoke(installer.remote, plan, 'storage-inspect')


def begin(installer, action, artifacts, versions, expected, configuration, setup_activation=False, ramfs=False):
    if installer.store.pending(installer.profile):
        refuse()
    operation = uuid.uuid4().hex
    installer.store.check_capsule_storage(installer.profile)
    # No package request or durable pending receipt until storage is usable.
    root_ssh = installer.profile.get('connection') == 'root-ssh'
    handoff=getattr(installer,'_root_handoff',None)
    selected = root_ssh_storage(installer, ramfs) if root_ssh else None
    check_plan = make_plan(operation, uuid.uuid4().hex, action, artifacts, versions, PUBLIC_ROOT, root_ssh=root_ssh,
                           private_root=selected, root_handoff=handoff)
    fresh_install = action == 'install'
    review = getattr(installer, 'storage_preflight_review', None) if fresh_install else None
    needs_selection = not root_ssh
    for retry in (False, True):
        try:
            if needs_selection:
                selected = invoke(installer.remote, check_plan, 'storage-select', fresh_install=fresh_install)['root']
                if selected == ROOT:
                    selected = None  # Preserve legacy plans and capsule bindings.
                else:
                    check_plan['private_root'] = selected
                needs_selection = False
            if review is not None:
                invoke(installer.remote, check_plan, 'storage-check', fresh_install=True, read_only_storage=True)
                if retry:
                    review(None)
            invoke(installer.remote, check_plan, 'storage-check', fresh_install=fresh_install)
            break
        except UserError as error:
            if review is None or retry or error.reason_code != 'storage-preflight-failed':
                raise
            review(error)
    before_staging = getattr(installer, 'before_no_root_staging', None) if fresh_install else None
    if before_staging is not None:
        before_staging()
    elif fresh_install and setup_activation:
        installer.prepare_install_helper(True)
    install_stop = getattr(installer, '_install_stop_generation', None) if setup_activation else None
    if setup_activation:
        installer._install_stop_generation = None
    owns_stop = (valid_generation(install_stop) and install_stop.startswith('S')
                 and helper_start_allowed(installer, allow_blocked=True)
                 and setup_generation(installer) == install_stop)
    start_cancelled = setup_activation and not owns_stop and (
        install_stop is not None or not helper_start_allowed(installer))
    from .operations import HELPER_STATE
    generation = install_stop if owns_stop else None
    expanded_state = False
    if start_cancelled and not root_ssh:
        expanded_state = setup_generation(installer, create='inspect-install-storage') is False
    if setup_activation and not (owns_stop or start_cancelled):
        generation = setup_generation(installer, create=True if root_ssh else 'install-or-defer-start')
        if generation is False:
            # Package delivery does not require an activation baseline.
            # Without one this operation must never automatically start Helper.
            expanded_state = True
            start_cancelled = True
            generation = None
    setup_start = {'generation': generation} if setup_activation else None
    installer.store.begin(installer.profile, 'install' if action == 'install' else 'uninstall',
                          recovery_protocol=PROTOCOL, observer_operation=operation,
                          expected=expected, versions=versions)
    pending = installer.store.pending(installer.profile)
    config_hash=hashlib.sha256(canonical({name:hashlib.sha256(raw).hexdigest() for name,raw in configuration.items()}).encode()).hexdigest()
    configuration_directory = HELPER_STATE if expanded_state else None
    plan = make_plan(operation, pending['diagnostic_id'], action, artifacts, versions, PUBLIC_ROOT,config_hash,
                     root_ssh=root_ssh,private_root=selected,root_handoff=handoff,setup_start=setup_start,
                     configuration_directory=configuration_directory)
    capsule = dict(schema=1, profile=installer.profile, plan=plan,
                   source=source_for(root_ssh, selected, configuration_directory, plan.get('screensaver') is True), expected=expected,
                   artifacts={name: base64.b64encode(raw).decode() for name, raw in artifacts.items()},
                   configuration={name: raw.decode('utf8') for name, raw in configuration.items()})
    digest = installer.store.save_capsule(installer.profile, operation, capsule)
    installer.store.checkpoint(installer.profile, capsule_sha256=digest,
                               **({'setup_cancelled':True} if start_cancelled else {}),
                               **({'setup_install_stop':install_stop} if owns_stop else {}),
                               **({'observer_source_sha256':plan['source_sha256']} if expanded_state or plan.get('screensaver') else {}))
    if handoff:
        from .root_no_root_handoff import call
        call(installer.remote,installer.remote._cytv_root_handoff_support,'claim',plan=plan)
    invoke(installer.remote, plan, 'prepare')
    stage_remaining(installer,capsule)
    return installer.store.pending(installer.profile)


def stage_remaining(installer, value):
    """Only missing unclaimed paths; never replace changed or claimed payloads."""
    plan=value['plan']
    if plan['action']!='install':return
    missing=invoke(installer.remote,plan,'artifacts').get('missing')
    if not isinstance(missing,list) or any(type(index) is not int or not 0 <= index < len(plan['slots']) for index in missing):refuse()
    for index in missing:
        name=('helper.ipk', 'launcher.ipk', SCREENSAVER_IPK)[index]
        raw=base64.b64decode(value['artifacts'][name],validate=True)
        invoke(installer.remote,plan,'upload-artifact',index,data=raw)
    if invoke(installer.remote,plan,'artifacts').get('missing')!=[]:refuse()


def capsule(installer, pending):
    if (not pending or pending.get('recovery_protocol') != PROTOCOL or 'previous' in pending or
            pending.get('action') not in ('install', 'uninstall') or installer.profile['edition'] != 'no-root'):
        refuse()
    value = installer.store.read_capsule(installer.profile, pending.get('observer_operation'), pending.get('capsule_sha256'))
    try:
        plan = value['plan']
        if (value['schema'] != 1 or value['profile'] != installer.profile or plan['operation'] != pending['observer_operation'] or
                plan['diagnostic_id'] != pending['diagnostic_id'] or plan['protocol'] != PROTOCOL or
                plan['action'] != ('install' if pending['action'] == 'install' else 'remove') or
                hashlib.sha256(value['source'].encode()).hexdigest() != plan['source_sha256'] or
                value['expected'] != pending['expected']):
            refuse()
        if value['source'] != source_for(installer.profile.get('connection') == 'root-ssh',
                                         plan.get('private_root'), plan.get('configuration_directory'), plan.get('screensaver') is True):
            raise LocalRecoveryError('source-incompatible')
        if ('configuration_directory' in plan or plan.get('screensaver')) and pending.get('observer_source_sha256') != plan['source_sha256']:
            refuse()
        artifacts = {name: base64.b64decode(raw, validate=True) for name, raw in value['artifacts'].items()}
        config_hash=hashlib.sha256(canonical({name:hashlib.sha256(raw.encode()).hexdigest() for name,raw in value['configuration'].items()}).encode()).hexdigest()
        rebuilt = make_plan(plan['operation'], plan['diagnostic_id'], plan['action'], artifacts, pending['versions'], PUBLIC_ROOT,config_hash,
                            root_ssh=installer.profile.get('connection') == 'root-ssh', private_root=plan.get('private_root'),root_handoff=plan.get('root_handoff'),setup_start=plan.get('setup_start'),
                            configuration_directory=plan.get('configuration_directory'))
        rebuilt['source_sha256'] = plan['source_sha256']
        if rebuilt != plan:
            refuse()
        if 'root_handoff' in plan:
            from .root_no_root_handoff import support
            installer.remote._cytv_root_handoff_support=support(installer)
        if plan['action'] == 'install':
            from .operations import HELPER_STATE
            if set(value['configuration']) != {'ssap-key.json', 'apps.json'}:
                refuse()
            for name, raw in value['configuration'].items():
                if hashlib.sha256(raw.encode()).hexdigest() != value['expected'][HELPER_STATE+'/'+name]:
                    refuse()
        return value
    except (KeyError, ValueError, TypeError):
        refuse()


FILE_CHECK = r'''
(function(){
 var fs=require('fs'),c=require('constants'),crypto=require('crypto'),path=require('path');
 var expected=JSON.parse(process.argv[process.argv.length-1]);
 Object.keys(expected).forEach(function(name){
  for(var parent=path.dirname(name);;parent=path.dirname(parent)){
   var directory=fs.lstatSync(parent);if(!directory.isDirectory()||directory.isSymbolicLink())throw Error('unsafe-parent');
   if(parent===path.dirname(parent))break;
  }
  var before=fs.lstatSync(name);
  if(!before.isFile()||before.nlink!==1||before.size>128*1024*1024)throw Error('unsafe-file');
  var fd=fs.openSync(name,c.O_RDONLY|c.O_NOFOLLOW|c.O_NONBLOCK),hash=crypto.createHash('sha256'),b=new Buffer(65536),n;
  try{
   var opened=fs.fstatSync(fd);if(opened.ino!==before.ino||opened.dev!==before.dev)throw Error('changed-file');
   while((n=fs.readSync(fd,b,0,b.length,null))>0)hash.update(b.slice(0,n));
   var after=fs.lstatSync(name);if(after.ino!==before.ino||after.dev!==before.dev||after.size!==before.size)throw Error('changed-file');
  }finally{fs.closeSync(fd);}
  if(hash.digest('hex')!==expected[name])throw Error('changed-content');
 });process.stdout.write('CYTV_ORIGINAL_FILES_VERIFIED');
}());
'''

from .tv_sources import node_adapter

STATE_CHECK = node_adapter('state-permissions', r"""
var option=process.argv[process.argv.length-2],directory=process.argv[process.argv.length-1];
var packagedState=option.indexOf('packaged-state:')===0;
if(packagedState)option=option.slice('packaged-state:'.length);
var verifyHashes=packagedState&&/^verify:([a-f0-9]{64}):([a-f0-9]{64})$/.exec(option);
var match=/^(repair-key-mode|check-stale-key|replace-stale-key):([a-f0-9]{64})(?::([a-f0-9]{64}))?$/.exec(option);
var expected=match?match[2]:null;
var recoverStaleKey=!!match&&match[1]!=='repair-key-mode';
var repair=option==='repair-key-mode'||expected,rootRepair=false;
if(recoverStaleKey&&process.getuid()===0)throw Error('unsafe-config-owner');
function effectiveIdentity(uid,gid){
 if(typeof process.geteuid==='function'&&typeof process.getegid==='function')
  return process.geteuid()===uid&&(gid===undefined||process.getegid()===gid);
 // Older LG Node builds expose real IDs only. Linux reports effective IDs in column two.
 var status=require('fs').readFileSync('/proc/self/status','utf8');
 var user=/^Uid:[ \t]+\d+[ \t]+(\d+)[ \t]+\d+[ \t]+\d+$/m.exec(status);
 var group=/^Gid:[ \t]+\d+[ \t]+(\d+)[ \t]+\d+[ \t]+\d+$/m.exec(status);
 return !!user&&!!group&&Number(user[1])===uid&&(gid===undefined||Number(group[1])===gid);
}
if(repair&&process.getuid()===0&&
   directory==='/media/developer/apps/usr/palm/applications/com.local.nativehome/state'){
 if(!effectiveIdentity(0))throw Error('unsafe-config-owner');
 var fs=require('fs'),before=fs.lstatSync(directory);
 if(!expected||!before.isDirectory()||before.isSymbolicLink()||before.uid!==5999||before.gid!==5000)
  throw Error('unsafe-config-owner');
 // Keep completed-file continuations boot-readable too: no later observer
 // upload is guaranteed to repair a root-owned key. Drop permanently first.
 process.chdir('/');process.setgroups([]);process.setgid(5000);process.setuid(5999);
 var after=fs.lstatSync(directory);
 if(process.getuid()!==5999||process.getgid()!==5000||!effectiveIdentity(5999,5000)||
    process.getgroups().some(function(g){return g!==5000;})||
    after.dev!==before.dev||after.ino!==before.ino||after.uid!==5999||after.gid!==5000)
  throw Error('unsafe-config-owner');
 rootRepair=true;
}
var options={expectedHash:expected,requireHash:rootRepair,recoverStaleKey:recoverStaleKey,packagedState:packagedState,
 verifyHashes:verifyHashes&&verifyHashes.slice(1)};
if(match&&match[1]==='replace-stale-key'){
 // Read only the capsule's bounded private payload from SSH stdin.
 var data=typeof Buffer.alloc==='function'?Buffer.alloc(65537):new Buffer(65537);
 var offset=0,fs=require('fs');
 while(offset<data.length){
  var count=fs.readSync(0,data,offset,data.length-offset,null);
  if(!count)break;
  offset+=count;
 }
 if(!offset||offset===data.length||!match[3])throw Error('invalid-key-replacement');
 options.replacementKey=data.slice(0,offset);
 options.staleKeyIdentity=match[3];
}
var result=repair?contract.prepareConfiguration(directory,options):contract.inspectConfiguration(directory,options);
process.stdout.write(typeof result==='string'?'CYTV_STALE_PAIRING_KEY '+result:'CYTV_CONFIGURATION_PRIVATE');
""")

EMPTY_PACKAGE = r'''
(function(){
 var fs=require('fs'),path=require('path'),c=require('constants'),args=JSON.parse(process.argv[process.argv.length-1]);
 if(['com.local.nativehome','com.gathin.tvhome'].indexOf(args.app)<0)throw Error('unexpected-app');
 function exists(name){try{fs.lstatSync(name);return true;}catch(e){if(e.code==='ENOENT')return false;throw e;}}
 var service=args.app+(args.app==='com.gathin.tvhome'?'.renewal':'.service'),directory=args.base+'/packages/'+args.app;
 if(exists(args.base+'/applications/'+args.app)||exists(args.base+'/services/'+service))throw Error('application-remains');
 for(var current=directory;;current=path.dirname(current)){
  var s=fs.lstatSync(current);if(!s.isDirectory()||s.isSymbolicLink())throw Error('unsafe-parent');
  if(current===path.dirname(current))break;
 }
 var before=fs.lstatSync(directory);
 if((before.uid!==process.getuid()&&before.uid!==0&&!(before.uid===5999&&before.gid===5000))||(before.mode&2)||fs.readdirSync(directory).length)throw Error('foreign-metadata');
 if(args.cleanup===true){
  var fd=fs.openSync(directory,c.O_RDONLY|c.O_NOFOLLOW);
  try{var opened=fs.fstatSync(fd);if(opened.dev!==before.dev||opened.ino!==before.ino)throw Error('changed-metadata');fs.rmdirSync(directory);}
  finally{fs.closeSync(fd);}
 }
 process.stdout.write('CYTV_EMPTY_PACKAGE');
}());
'''


def empty_package(installer, app, cleanup=False):
    from .operations import BASE
    args={'base':BASE,'app':app,'cleanup':cleanup}
    if installer.remote.run('/usr/bin/node -e '+shlex.quote(EMPTY_PACKAGE)+' '+shlex.quote(canonical(args))).strip()!='CYTV_EMPTY_PACKAGE':refuse()


def files_match(installer, expected):
    if not expected:
        refuse()
    if installer.remote.run('/usr/bin/node -e '+shlex.quote(FILE_CHECK)+' '+shlex.quote(canonical(expected))).strip() != 'CYTV_ORIGINAL_FILES_VERIFIED':
        refuse()


def readback(installer, value, index, allow_empty=False):
    plan = value['plan']; slot = plan['slots'][index]; app = slot['app']
    if plan['action'] == 'remove':
        if any(item['id'] == app for item in installer.installed_apps()):
            refuse()
        try:installer.verify_absent(app)
        except UserError:
            if not allow_empty:raise
            empty_package(installer,app)
        return
    deadline = time.monotonic()+10
    while time.monotonic()<deadline:
        observed=installer.installed_apps(timeout=deadline-time.monotonic())
        from .diagnostic_context import status_summary
        installer.tv_info['components']=status_summary({'device':{'apps':observed}}).get('components',{})
        apps = {item['id']: item.get('version') for item in observed}
        if time.monotonic()>=deadline:
            break
        if apps.get(app) == slot['version']:
            break
        time.sleep(min(1,max(0,deadline-time.monotonic())))
    if time.monotonic()>=deadline:
        raise UserError('Installed version did not match the package. Run cytv status; do not retry blindly.',reason_code='version-mismatch')
    paths = {name: digest for name, digest in value['expected'].items()
             if ('/'+app+'/' in name or '/'+app+'.service/' in name or '/'+app+'.renewal/' in name)
             and '/state/' not in name}
    files_match(installer, paths)


def snapshot(installer, value):
    plan = value['plan']
    for attempt in range(3):
        try:
            result = invoke(installer.remote, plan, 'status')
            break
        except UserError as error:
            details = getattr(error, 'no_root_observer', {})
            # A detached writer can be publishing a claim or terminal while
            # status reads it. Retry the read without changing evidence checks.
            publishing = (details.get('observer_reason') in ('unsafe-file', 'changed-file', 'short-read')
                          or details.get('exception_name') == 'SyntaxError')
            if attempt == 2 or details.get('failure') != 'observer-error' or not publishing:
                raise
            time.sleep(0.1)
    if (result.get('protocol')!=PROTOCOL or result.get('plan_sha256')!=hashlib.sha256(canonical(plan).encode()).hexdigest()
            or not isinstance(result.get('slots'),list) or len(result['slots'])!=len(plan['slots'])
            or result.get('reservation') not in ('active','prepared','closed','busy','unknown')
            or not isinstance(result.get('configuration'),dict)
            or set(result['configuration'])!=set(('files','eim','launch') if plan['action']=='install' else ('restore',))
            or any(state not in ('prepared','unknown','complete') for state in result['configuration'].values())):
        raise observation_error('status', 'invalid-status')
    for slot in result['slots']:
        if (not isinstance(slot,dict) or slot.get('submission') not in ('prepared','claimed-possibly-submitted','sealed') or
                slot.get('terminal') not in ('none','success','failure') or slot.get('readback') not in ('matches','not-checked')):
            raise observation_error('status', 'invalid-status')
    return result


def _install_packages_complete(plan, result):
    return (plan['action'] == 'install' and result['reservation'] == 'active'
            and all(slot['terminal'] == 'success' and not slot.get('reason') for slot in result['slots']))


def observe(installer, pending, *, read_only=False):
    value=capsule(installer,pending)
    if 'root_handoff' in value['plan']:
        if read_only:
            # Handoff observation would stage a temporary gate on the TV.
            return dict(device={}, pending=pending, reconciled=None, can_resume_root_setup=False,
                        no_root_ready=False, no_root_reason='observation-unverified')
        from .root_no_root_handoff import continuation
        if continuation(installer,value['plan']) in ('unclaimed','unprepared'):
            return dict(device={'observer':{'operation':value['plan']['operation']}},pending=pending,
                        reconciled=None,can_resume_root_setup=False,no_root_ready=True,no_root_reason='original-work-remaining')
    result=snapshot(installer,value)
    ready=True
    reason='original-work-remaining'
    if result.get('reservation') not in ('active','prepared','closed'):
        ready=False;reason='original-reservation-unverified'
    if 'unknown' in result.get('configuration',{}).values():
        ready=False;reason='original-configuration-unknown'
    for index,slot in enumerate(result['slots']):
        if slot.get('reason'):
            ready=False;reason='original-terminal-unknown';break
        if slot['terminal']=='failure':
            ready=False;reason='original-vendor-failure';break
        if slot['submission']=='claimed-possibly-submitted' and slot['terminal']=='none':
            ready=False;reason='original-terminal-unknown';break
        if slot['terminal']=='success' or slot['submission']=='sealed':
            try:readback(installer,value,index,allow_empty=slot['terminal']=='success')
            except (RuntimeError,ValueError,KeyError):ready=False;reason='original-readback-unverified';break
    if ready and plan_is_configured(value,result):
        try:configuration_readback(installer,value)
        except (RuntimeError,ValueError,KeyError):ready=False;reason='original-readback-unverified'
    if (ready and value['plan']['action'] == 'install' and result['reservation'] == 'active'
            and any(slot['submission'] == 'prepared' for slot in result['slots'])):
        try:
            invoke(installer.remote, value['plan'], 'artifacts')
        except UserError as error:
            details = getattr(error, 'no_root_observer', {})
            # Prepare can attach before creating staging and submitting any slot.
            if not (details.get('exception_code') == 'ENOENT'
                    and details.get('storage_area') == 'public-staging'
                    and all(slot['submission'] == 'prepared' for slot in result['slots'])):
                ready = False
                reason = 'original-staging-unverified'
    configuration_remaining = (ready and _install_packages_complete(value['plan'], result)
                               and 'prepared' in result['configuration'].values())
    return dict(device={'observer':result},pending=pending,reconciled=None,can_resume_root_setup=False,
                no_root_ready=ready,no_root_reason=reason,no_root_configuration_remaining=configuration_remaining)


def valid_generation(value):
    return type(value) is str and re.fullmatch(r'[IS][a-f0-9]{32}', value) is not None


GENERATION_CHECK = node_adapter('state-permissions', r"""
// CYTV_SETUP_GENERATION: fixed Helper state only; no retained source is executed.
var input=JSON.parse(process.argv[process.argv.length-1]),fs=require('fs');
try { fs.lstatSync(input.directory); }
catch(e) { if(e.code!=='ENOENT')throw e;process.stdout.write('null');return; }
if(input.create==='inspect-install-storage'){
 process.stdout.write(contract.isPackagedStateExpanded(input.directory)?'false':'null');return;
}
process.stdout.write(JSON.stringify(contract.stopGeneration(input.directory,input.create===true?'install':input.create)));
""")


def setup_generation(installer, create=False):
    from .operations import HELPER_STATE
    request={'directory':HELPER_STATE,'create':create}
    try:
        value=json.loads(installer.remote.run('/usr/bin/node -e '+shlex.quote(GENERATION_CHECK)+' '+shlex.quote(canonical(request))))
    except (ValueError,TypeError):refuse()
    if value is False and create in ('install-or-defer-start', 'inspect-install-storage'):
        return value
    if value is not None and not valid_generation(value):refuse()
    return value


def setup_launch_generation(installer, plan):
    expected=plan['setup_start']['generation']
    pending=installer.store.pending(installer.profile) or {}
    own_stop = valid_generation(expected) and expected.startswith('S') and pending.get('setup_install_stop') == expected
    if ('configuration_directory' in plan or pending.get('setup_cancelled')
            or not helper_start_allowed(installer, allow_blocked=own_stop)):
        return None
    current=setup_generation(installer,create='setup' if expected is None and pending.get('setup_launch_generation') is None else False)
    if expected is None:
        # Fresh state may adopt only initialization, never a Stop published
        # while packages were being installed.
        if current is None or not current.startswith('I'):return None
        pinned=pending.get('setup_launch_generation')
        if pinned is not None and (not valid_generation(pinned) or not pinned.startswith('I')):refuse()
        if pinned is not None and pinned!=current:return None
    elif current!=expected:return None
    return current


def helper_start_allowed(installer, *, allow_blocked=False):
    from .operations import HELPER_STATE
    names = ('watchdog',) if allow_blocked else ('blocked', 'watchdog')
    paths = [shlex.quote(HELPER_STATE + '/' + name) for name in names]
    retained = ' || '.join(f'[ -e {path} ] || [ -L {path} ]' for path in paths)
    command = f'if {retained}; then printf CYTV_STOP_RETAINED; else printf CYTV_START_ALLOWED; fi'
    result = installer.remote.run(command).strip()
    if result not in ('CYTV_START_ALLOWED', 'CYTV_STOP_RETAINED'):
        raise UserError('Startup could not be verified. Save the diagnostic report; do not reinstall blindly.', reason_code='helper-state-unverified')
    return result == 'CYTV_START_ALLOWED'


def guard_helper(installer):
    if not helper_start_allowed(installer):
        raise UserError('Home Helper remains stopped by its safety control. Recovery data was kept; use the TV controls to review it.',reason_code='pending-operation')


def claim_step(installer,plan,step):
    claim=invoke(installer.remote,plan,'config-claim',step)
    if claim.get('state')=='complete':return None
    token=claim.get('nonce')
    if claim.get('won') is not True or not isinstance(token,str) or len(token)!=64:refuse()
    return token


def finish_step(installer,plan,step,token,result='verified'):
    invoke(installer.remote,plan,'config-result',step,proof={'nonce':token,'result':result})


def plan_is_configured(value,result):
    return value['plan']['action']=='install' and result.get('configuration',{}).get('files')=='complete'


def configuration_readback(installer,value):
    from .operations import HELPER_STATE
    expected = {name: value['expected'][HELPER_STATE+'/'+name] for name in value['configuration']}
    packaged_state = 'configuration_directory' in value['plan']
    mode = (' packaged-state:verify:'+expected['ssap-key.json']+':'+expected['apps.json']
            if packaged_state else '')
    if installer.remote.run('/usr/bin/node -e '+shlex.quote(STATE_CHECK)+mode+' '+shlex.quote(HELPER_STATE)).strip()!='CYTV_CONFIGURATION_PRIVATE':
        refuse()
    if not packaged_state:
        files_match(installer, {HELPER_STATE+'/'+name: digest for name, digest in expected.items()})


def restore_original(installer):
    """A lost original delete reply stays unknown, regardless of current EIM."""
    from .operations import HOME
    installer.stop_helper()
    receipt=installer.store.device_dir(installer.profile)/'installation.json'
    installation=json.loads(receipt.read_text()) if receipt.exists() else {}
    pending=installer.store.pending(installer.profile) or {}
    if pending.get('eim_registered',installation.get('eim_registered','unknown')) is not False:
        installer.remote.luna('com.webos.service.eim/deleteDevice',{'appId':HOME})
        installer.save_eim(False)
    installer.remote.luna('com.webos.applicationManager/launch',{'id':'com.webos.app.home'})


PREPARE_HOME_CHANNEL = node_adapter('state-permissions', """
contract.prepareChannel('/media/developer/apps/usr/palm/services/com.gathin.tvhome.renewal/state/home-control');
""")


def configure(installer,value):
    from .operations import HELPER_STATE, HOME, HELPER
    from .errors import TVRejected
    plan=value['plan']
    expected={HELPER_STATE+'/'+name:value['expected'][HELPER_STATE+'/'+name] for name in value['configuration']}
    # Only an authenticated install continuation with an idle Helper can
    # restrict the known vendor-normalized key mode. Status stays read-only;
    # immutable observer/capsule bytes and emergency latches are untouched.
    repair=installer.helper_state() in ('stopped','stale')
    key_hash = expected[HELPER_STATE + '/ssap-key.json']
    developer_mode = installer.profile.get('connection') != 'root-ssh'
    command = '/usr/bin/node -e ' + shlex.quote(STATE_CHECK)
    directory = shlex.quote(HELPER_STATE)
    packaged_state = 'configuration_directory' in plan
    prefix = 'packaged-state:' if packaged_state else ''
    if repair:
        action = 'check-stale-key' if developer_mode else 'repair-key-mode'
        mode = f'{prefix}{action}:{key_hash}'
    else:
        mode = prefix + 'inspect'
    result = installer.remote.run(f'{command} {shlex.quote(mode)} {directory}').strip()
    stale_key = re.fullmatch(r'CYTV_STALE_PAIRING_KEY ([a-f0-9]{64})', result)
    if stale_key and repair and developer_mode:
        from .tv import SSAP
        pending = installer.store.pending(installer.profile)
        if snapshot(installer, value)['configuration']['files'] != 'prepared':
            refuse()
        key_data = value['configuration']['ssap-key.json']
        profile = installer.profile
        # The retained TV file is not proof of pairing. Authenticate the
        # original capsule's key before allowing the adapter to replace it.
        with SSAP(profile['host'], installer.store.device_dir(profile), installer.progress, reuse_only=True) as paired:
            if paired.key != json.loads(key_data)['key']:
                refuse()
        current = snapshot(installer, value)
        if (installer.store.pending(profile) != pending or current['reservation'] != 'active'
                or current['configuration']['files'] != 'prepared'
                or installer.helper_state() not in ('stopped', 'stale')):
            refuse()
        mode = shlex.quote(f'{prefix}replace-stale-key:{key_hash}:{stale_key[1]}')
        result = installer.remote.run(f'{command} {mode} {directory}', data=key_data.encode()).strip()
    if result != 'CYTV_CONFIGURATION_PRIVATE':
        refuse()
    token=claim_step(installer,plan,'files')
    if token:
        if installer.helper_state() not in ('stopped','stale'):refuse()
        for name,raw in value['configuration'].items():
            proof={'nonce':token,'directory':HELPER_STATE,'name':name,
                   'hashes':{key:hashlib.sha256(text.encode()).hexdigest() for key,text in value['configuration'].items()}}
            invoke(installer.remote,plan,'upload-configuration',proof=proof,data=raw.encode())
    if packaged_state:
        configuration_readback(installer, value)
    else:
        files_match(installer,expected)
    if token:
        finish_step(installer,plan,'files',token)
    # Repair the fixed transient channel with the trusted installer source.
    # Other SSH identities can still use a correctly provisioned channel.
    if repair:
        try:
            installer.remote.run('/usr/bin/node', data=PREPARE_HOME_CHANNEL.encode(), timeout=10)
        except (OSError, RuntimeError):
            pass  # Broker status remains unknown; independent setup may continue.
    installer.store.checkpoint(installer.profile,configuration_stage='eim-ready')
    token=claim_step(installer,plan,'eim')
    if token:
        installer.store.checkpoint(installer.profile,configuration_stage='eim-submitted')
        disposition='verified'
        try:
            configuration_luna(installer,plan,'com.webos.service.eim/addDevice',{'appId':HOME,'pigImage':'','mvpdIcon':''})
            installer.save_eim(True)
        except TVRejected:
            installer.save_eim(installer.read_eim())
            disposition='unavailable'
            installer.progress('Warning: early input restoration is unavailable; startup will use the guarded fallback.')
        finish_step(installer,plan,'eim',token,disposition)
    installer.store.checkpoint(installer.profile,configuration_stage='launch-ready')
    # Read-only guard occurs before claiming; an emergency marker may be reviewed
    # on the TV without consuming the still-unsubmitted automatic launch.
    state=snapshot(installer,value)
    setup='setup_start' in plan
    generation=setup_launch_generation(installer,plan) if setup else None
    cancelled=setup and generation is None
    if not setup and state.get('configuration',{}).get('launch')=='prepared':guard_helper(installer)
    token=claim_step(installer,plan,'launch')
    if token and cancelled:
        installer.store.checkpoint(installer.profile,setup_cancelled=True)
        finish_step(installer,plan,'launch',token)
    elif token:
        installer.store.checkpoint(installer.profile,configuration_stage='launch-submitted',
                                   **({'setup_launch_generation':generation} if setup else {}))
        installer.outcome.launch_submitted()
        params={'nativeHomeSetup':generation} if setup else {'nativeHomeAuto':True}
        configuration_luna(installer,plan,'com.webos.applicationManager/launch',{'id':HELPER,'params':params})
        installer.outcome.launch_accepted()
        finish_step(installer,plan,'launch',token)
    installer.store.checkpoint(installer.profile,configuration_stage='complete')


def configuration_luna(installer,plan,uri,payload):
    if 'root_handoff' not in plan:return installer.remote.luna(uri,payload)
    from .root_no_root_handoff import call
    from .transport import terminal_reply
    raw=call(installer.remote,installer.remote._cytv_root_handoff_support,'luna',plan=plan,uri=uri,payload=payload)
    value=json.loads(raw)
    if not terminal_reply(value,uri=uri):refuse()
    return value


def continue_operation(installer, expected_pending):
    pending=installer.store.pending(installer.profile)
    if pending!=expected_pending:
        refuse()
    value=capsule(installer,pending);plan=value['plan']
    if 'root_handoff' in plan:
        from .root_no_root_handoff import call,continuation
        call(installer.remote,installer.remote._cytv_root_handoff_support,'claim',plan=plan)
        if continuation(installer,plan)=='unprepared':
            invoke(installer.remote,plan,'prepare',source=value['source'])
    result=snapshot(installer,value)
    if installer.store.pending(installer.profile)!=pending:
        refuse()
    if not result.get('closed'):
        # An attached install with all vendor replies can finish from the
        # installed packages. No new request needs the temporary IPKs.
        packages_installed = _install_packages_complete(plan, result)
        if not packages_installed and result['reservation'] in ('prepared','active'):
            invoke(installer.remote,plan,'prepare',source=value['source'])
        invoke(installer.remote,plan,'attach')
        if not packages_installed:
            stage_remaining(installer,value)
        if plan['action']=='remove':
            token=claim_step(installer,plan,'restore')
            if token:
                restore_original(installer)
                finish_step(installer,plan,'restore',token)
            installer.store.checkpoint(installer.profile,restored_before_removal=True)
        for index in range(len(plan['slots'])):
            result=snapshot(installer,value);slot=result['slots'][index]
            if slot['terminal']=='failure':
                from .errors import TVRejected
                raise TVRejected('TV package operation failed. Run cytv status before retrying.',slot.get('reply'),plan['slots'][index]['method'])
            if slot['submission']=='prepared':
                if plan['action']=='remove' and not any(item['id']==plan['slots'][index]['app'] for item in installer.installed_apps()):
                    installer.verify_absent(plan['slots'][index]['app'])
                    invoke(installer.remote,plan,'seal',index)
                else:
                    invoke(installer.remote,plan,'start',index)
                    deadline=time.monotonic()+155
                    while True:
                        result=snapshot(installer,value);slot=result['slots'][index]
                        if slot['terminal']!='none' or slot.get('reason'):
                            break
                        if time.monotonic()>=deadline:
                            refuse()
                        time.sleep(.2)
            result=snapshot(installer,value);slot=result['slots'][index]
            if slot['terminal']=='failure':
                from .errors import TVRejected
                raise TVRejected('TV package operation failed. Run cytv status before retrying.',slot.get('reply'),plan['slots'][index]['method'])
            if slot.get('reason') or slot['terminal']!='success' and slot['submission']!='sealed':
                refuse()
            if plan['action']=='remove' and slot['terminal']=='success':
                try:installer.verify_absent(plan['slots'][index]['app'])
                except UserError:empty_package(installer,plan['slots'][index]['app'],cleanup=True)
            readback(installer,value,index)
            invoke(installer.remote,plan,'readback',index)
        # Re-read all packages; earlier success is historical, not current state.
        for index in range(len(plan['slots'])):readback(installer,value,index)
        if plan['action']=='install':
            installer.outcome.packages_verified()
            configure(installer,value)
        invoke(installer.remote,plan,'configured')
    else:
        for index in range(len(plan['slots'])):readback(installer,value,index)
        if plan['action']=='install':configuration_readback(installer,value)
    setup = plan['action']=='install' and 'setup_start' in plan
    setup_receipt = installer.store.pending(installer.profile) or {}
    cancelled = setup and setup_receipt.get('setup_cancelled') is True
    expected_generation = (plan['setup_start']['generation'] or setup_receipt.get('setup_launch_generation')) if setup else None
    result=invoke(installer.remote,plan,'release')
    record = {'action': 'finish-no-root-operation', 'stage': 'verified',
              'previous': installer.store.pending(installer.profile), 'observer': result}
    try:
        invoke(installer.remote,plan,'retire')
    except RuntimeError as error:
        details = getattr(error, 'no_root_observer', {})
        staging_error = (details.get('storage_area') in ('public-staging', 'storage-parent')
                         or details.get('observer_reason') in (
                             'changed-artifact', 'changed-public-stage', 'private-public-parent',
                             'unsafe-directory', 'writable-directory'))
        if (plan['action'] != 'install' or details.get('failure') != 'observer-error'
                or not staging_error or not snapshot(installer, value).get('closed')):
            raise UserError('Packages are verified, but temporary package cleanup is incomplete. Recovery data was kept.',reason_code='pending-operation') from None
        record['staging_cleanup'] = details
        installer.progress('Temporary No-root package files could not be safely removed.')
    from .state import private_write
    archive=installer.store.recovery(installer.profile,'finish-no-root-operation')
    private_write(archive,json.dumps(record).encode())
    installer.store.finish(installer.profile)
    try:
        installer.store.retire_capsule(installer.profile,pending['observer_operation'],pending['capsule_sha256'])
    except (RuntimeError,OSError):
        installer.progress('Setup is verified, but the private recovery capsule could not be removed. Keep the local record for cleanup.')
    if plan['action']=='install':
        installer.outcome.packages_verified()
        if setup and expected_generation is not None and setup_receipt.get('setup_cancelled') is not True:
            # Configuration's committed launch result proves the historical ACK,
            # including on a closed retry; it never submits another launch.
            installer.outcome.launch_accepted()
        observed='unverified'
        try:
            current=installer.helper_state(timeout=5)
            observed='process-observed' if current=='running' else 'not-observed' if current in ('stopped','stale') else 'unverified'
        except Exception:pass
        if setup and not cancelled:
            try:
                # Sample after release/retire/receipt completion and the process
                # probe: a Stop in any of those stages still wins the result.
                cancelled = cancelled or setup_generation(installer) != expected_generation
            except (RuntimeError,OSError):
                installer.outcome.startup_observed('unverified')
                raise UserError('Startup could not be verified. Save the diagnostic report; do not reinstall blindly.', reason_code='helper-state-unverified')
        if cancelled:
            installer.outcome.cancelled_by_stop()
            installer.progress(START_HELPER)
            return {'installed':'no-root','launch_requested':installer.outcome.values['launch_request']=='accepted',
                    'activation_cancelled':True,'hardware_verified':False}
        installer.outcome.startup_observed(observed)
    return {'installed':'no-root','launch_requested':True,'hardware_verified':False} if plan['action']=='install' else {'removed':True}
