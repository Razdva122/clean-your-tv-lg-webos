"""Windowed cytv wizard. Run with python -m cytv.gui."""
import html
import json
import math
from pathlib import Path
import shutil
import subprocess
import sys
import threading
from time import monotonic

from PySide6.QtCore import QEvent, QObject, Signal, QUrl, QTimer, Qt
from PySide6.QtGui import QDesktopServices, QIcon, QFontDatabase, QFont, QPixmap, QTextCursor
from PySide6.QtWidgets import (QApplication, QFileDialog, QFrame, QHBoxLayout,
                              QLabel, QLineEdit, QMainWindow, QMessageBox, QProgressBar,
                              QPushButton, QTextBrowser, QPlainTextEdit, QVBoxLayout, QWidget, QButtonGroup, QDialog, QScrollArea, QLayout, QCheckBox)

from cytv import __version__, cli, debloat, diagnostics, i18n, package
from cytv.i18n import translate as tr
from cytv.desktop import EXPLICIT_TV_CHOICE, Channel, SSH_COMMAND_PROMPT, RETRY_STORAGE_CHECK, RETRY_STORAGE_PROMPT
from cytv.errors import LocalRecoveryError
from cytv.root_runtime import BETA_TITLE
from cytv.state import Store
from cytv.gui_style import STYLE, TVPreview, Select, EditionOption, BrandSignature, WrappedLabel, ThemeCard, ToggleSwitch

MAINTENANCE_ACTIONS = (
    ('Review recovery options', 'recover'),
    ('Check TV status', 'status'),
    ('Check connection and create a diagnostic report', 'doctor'),
    ('Return to LG Home', 'restore'),
    ('Uninstall Clean Your TV', 'uninstall'),
    ('Home button diagnostics', 'home-diagnostics'),
    ('Enable updates for all TV components (root required)', 'enable-system-updates'),
    ('Clear WAM caches (root required)', 'clean-wam-cache'),
    ('Adjust LG settings (Debloat)', 'debloat'),
    ('Recover Root Updater rollback', 'recover-root-rollback'),
    ('Recover Root System Updater rollback', 'recover-system-rollback'),
)


REMOVAL_RECONNECT_SECONDS = 120


DIAGNOSTIC_ACTIONS = (
    ('Check connection and create a diagnostic report', 'doctor'),
    (SSH_COMMAND_PROMPT, 'ssh-command'),
)


class Events(QObject):
    event = Signal(str, object)


class Wizard(QMainWindow):
    def __init__(self, run=cli.interactive_main):
        super().__init__()
        i18n.configure()
        self.run = run
        self.running = False
        self.pending = None
        self.preparation = []
        self.collect_preparation = False
        self.report = None
        self.recovery_profile = None
        self.selected_profile = None
        self.doctor_result = None
        self.install_settings_current = {}
        self.debloat_results = {}
        self.recovery_plan = None
        self.failure_help = None
        self.reconnecting_after_reset = False
        self.removal_operation = None
        self.removal_watch = None
        self.worker = None
        self.setWindowTitle('Clean Your TV')
        self.resize(1060, 820)
        self.setMinimumSize(900, 680)
        self.apply_language_font()
        self.current_step = 0
        self.command = 'install'
        self.events = Events()
        self.events.event.connect(self.receive)
        body = QWidget()
        self.setCentralWidget(body)
        shell = QHBoxLayout(body)
        shell.setContentsMargins(0, 0, 0, 0)
        shell.setSpacing(0)
        sidebar = QWidget()
        sidebar.setObjectName('sidebar')
        sidebar.setFixedWidth(248)
        rail = QVBoxLayout(sidebar)
        rail.setContentsMargins(20, 24, 20, 26)
        rail.setSpacing(8)
        self.brand = BrandSignature(cli.payload_dir() / 'brand-stacked.svg')
        rail.addWidget(self.brand)
        rail.addSpacing(12)
        self.rail_title = QLabel()
        self.rail_title.setObjectName('railTitle')
        self.rail_title.setWordWrap(True)
        rail.addWidget(self.rail_title)
        rail.addSpacing(12)
        self.steps = QWidget()
        step_layout = QVBoxLayout(self.steps)
        step_layout.setContentsMargins(0, 0, 0, 0)
        step_layout.setSpacing(8)
        self.step_rows = []
        self.step_names = []
        self.step_numbers = []
        for number in range(1, 7):
            row = QFrame()
            row.setObjectName('step')
            line = QHBoxLayout(row)
            line.setContentsMargins(10, 7, 10, 7)
            line.setSpacing(12)
            marker = QLabel(str(number))
            marker.setObjectName('stepNumber')
            marker.setFixedSize(32, 32)
            marker.setAlignment(Qt.AlignmentFlag.AlignCenter)
            name = WrappedLabel('')
            name.setObjectName('stepName')
            line.addWidget(marker)
            line.addWidget(name, 1)
            self.step_rows.append(row)
            self.step_names.append(name)
            self.step_numbers.append(marker)
            step_layout.addWidget(row)
        rail.addWidget(self.steps)
        rail.addStretch()
        self.rail_note = QLabel()
        self.rail_note.setObjectName('railNote')
        self.rail_note.setWordWrap(True)
        rail.addWidget(self.rail_note)
        rail.addSpacing(20)
        version = QLabel('cytv ' + __version__)
        version.setObjectName('version')
        rail.addWidget(version)
        shell.addWidget(sidebar)
        main = QWidget()
        layout = QVBoxLayout(main)
        layout.setContentsMargins(40, 30, 40, 24)
        layout.setSpacing(12)
        header = QHBoxLayout()
        self.badge = QLabel()
        self.badge.setObjectName('badge')
        header.addWidget(self.badge)
        header.addStretch()
        self.language = Select()
        self.language.setObjectName('language')
        self.language.setAccessibleName(tr('Language'))
        for code, name in i18n.LANGUAGES.items():
            self.language.addItem(tr(name) if code == 'auto' else name, code)
        self.language.setCurrentIndex(list(i18n.LANGUAGES).index(i18n.language_choice()))
        self.language.currentIndexChanged.connect(self.change_language)
        header.addWidget(self.language)
        layout.addLayout(header)
        layout.addSpacing(18)
        self.title = QLabel()
        self.title.setObjectName('title')
        self.title.setWordWrap(True)
        layout.addWidget(self.title)
        self.subtitle = QLabel()
        self.subtitle.setObjectName('subtitle')
        self.subtitle.setWordWrap(True)
        layout.addWidget(self.subtitle)
        self.preview = TVPreview()
        layout.addWidget(self.preview)
        self.reading = QScrollArea()
        self.reading.setObjectName('wizardReading')
        self.reading.setWidgetResizable(True)
        self.reading.setFrameShape(QFrame.Shape.NoFrame)
        self.reading.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        reading_body = QWidget()
        reading_body.setObjectName('wizardReadingBody')
        reading_layout = QVBoxLayout(reading_body)
        reading_layout.setContentsMargins(0, 0, 0, 0)
        reading_layout.setSpacing(12)
        self.reading.setWidget(reading_body)
        layout.addWidget(self.reading, 1)
        self.content = QTextBrowser()
        self.content.setOpenExternalLinks(False)
        self.content.setOpenLinks(False)
        self.content.anchorClicked.connect(lambda url: self.show_reference(url.path()) if url.scheme() == 'guide' else None)
        self.content.document().setDefaultStyleSheet(
            'p { margin-top: 6px; margin-bottom: 12px; line-height: 140%; } '
            'h3 { color: #f3ede3; font-size: 16px; margin-top: 12px; margin-bottom: 10px; }')
        reading_layout.addWidget(self.content)
        self.check_results = {}
        self.check_panel = QTextBrowser()
        self.check_panel.setAccessibleName(tr('TV checks'))
        self.check_panel.setOpenLinks(False)
        self.check_panel.hide()
        reading_layout.addWidget(self.check_panel)
        self.progress = QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.setTextVisible(False)
        self.progress.setFixedHeight(5)
        self.progress.hide()
        layout.addWidget(self.progress)
        self.form = QWidget()
        self.form.setObjectName('form')
        self.form_layout = QVBoxLayout(self.form)
        self.form_layout.setContentsMargins(16, 16, 16, 16)
        self.form_layout.setSpacing(10)
        layout.addWidget(self.form)
        self.details_toggle = QPushButton()
        self.details_toggle.setCheckable(True)
        self.details_toggle.setObjectName('detailsToggle')
        self.details_toggle.setMinimumHeight(36)
        self.details_toggle.toggled.connect(self.toggle_details)
        self.details = QTextBrowser()
        self.details.setOpenExternalLinks(False)
        self.details.setAccessibleName(tr('Details'))
        reading_layout.addWidget(self.details)
        reading_layout.addStretch()
        for panel in (self.content, self.check_panel, self.details):
            panel.setFrameShape(QFrame.Shape.NoFrame)
            panel.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
            panel.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
            panel.installEventFilter(self)
            panel.viewport().installEventFilter(self)
            # Each rich-text section takes its full height within the shared viewport.
            panel.document().documentLayout().documentSizeChanged.connect(
                lambda size, panel=panel: panel.setFixedHeight(math.ceil(size.height())))
        footer = QHBoxLayout()
        footer.addWidget(self.details_toggle)
        footer.addStretch()
        self.cancel = QPushButton(tr('Close'))
        self.cancel.setObjectName('close')
        self.cancel.clicked.connect(self.close)
        footer.addWidget(self.cancel)
        layout.addLayout(footer)
        shell.addWidget(main, 1)
        self.home()

    def eventFilter(self, watched, event):
        event_type = event.type()
        if event_type in (QEvent.Type.ShowToParent, QEvent.Type.HideToParent, QEvent.Type.KeyPress):
            panels = (self.content, self.check_panel, self.details)
            if watched in panels:
                if event_type != QEvent.Type.KeyPress:
                    self.reading.setVisible(any(not panel.isHidden() for panel in panels))
                elif event.modifiers() == Qt.KeyboardModifier.NoModifier and event.key() in (
                        Qt.Key.Key_Up, Qt.Key.Key_Down, Qt.Key.Key_PageUp, Qt.Key.Key_PageDown,
                        Qt.Key.Key_Home, Qt.Key.Key_End):
                    QApplication.sendEvent(self.reading, event)
                    return True
        if event_type == QEvent.Type.Wheel and watched in (
                self.content.viewport(), self.check_panel.viewport(), self.details.viewport()):
            QApplication.sendEvent(self.reading.viewport(), event)
            return True
        return super().eventFilter(watched, event)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if hasattr(self, 'preview'):
            self.preview.setFixedHeight(144 if self.height() < 760 else 206)
        if hasattr(self, 'form'):
            choices = self.form.findChild(QScrollArea, 'runtimeChoices')
            if choices is not None:
                choices.setMinimumHeight(min(360, max(240, self.height()-440)))

    def apply_language_font(self):
        family = {'zh-Hans': 'Noto Sans SC', 'zh-Hant': 'Noto Sans TC'}.get(i18n.resolved_language())
        # Keep the existing typography for other languages and use the script's
        # packaged outlines ahead of system CJK fallback for Chinese.
        style = STYLE.replace('font-family: ', 'font-family: "' + family + '", ', 1) if family else STYLE
        self.setStyleSheet(style)

    def change_language(self):
        if self.running:
            return
        previous = i18n.language_choice()
        try:
            i18n.configure(self.language.currentData())
        except OSError:
            self.language.blockSignals(True)
            self.language.setCurrentIndex(list(i18n.LANGUAGES).index(previous))
            self.language.blockSignals(False)
            self.error_dialog('Could not save language preference', 'Check write access to the application data folder and try again.')
            return
        self.apply_language_font()
        self.language.setAccessibleName(tr('Language'))
        self.language.setItemText(0, tr('Auto'))
        self.cancel.setText(tr('Close'))
        self.home()

    def clear_form(self):
        def clear(layout):
            while layout.count():
                item = layout.takeAt(0)
                widget = item.widget()
                if widget:
                    widget.hide()
                    widget.setParent(None)
                    widget.deleteLater()
                elif item.layout():
                    clear(item.layout())
        clear(self.form_layout)

    def button(self, label, callback, default=False, layout=None):
        button = QPushButton(tr(label))
        button.setMinimumHeight(44)
        button.setCursor(Qt.CursorShape.PointingHandCursor)
        button.setDefault(default)
        button.setProperty('primary', default)
        button.clicked.connect(callback)
        (layout if layout is not None else self.form_layout).addWidget(button)
        return button

    def update_steps(self, number=0, result=None):
        self.current_step = number
        for index, row in enumerate(self.step_rows, 1):
            state = 'complete' if index < number else 'current' if index == number else 'upcoming'
            if result == 0:
                state = 'complete'
            elif index == number and result is not None:
                state = 'error' if result != 130 else 'upcoming'
            row.setProperty('state', state)
            self.step_numbers[index - 1].setText('✓' if state == 'complete' else '!' if state == 'error' else str(index))
            row.style().unpolish(row)
            row.style().polish(row)
            for label in (self.step_numbers[index - 1], self.step_names[index - 1]):
                label.style().unpolish(label)
                label.style().polish(label)
            row.update()

    def set_error_state(self, failed):
        for widget in (self.title, self.badge):
            widget.setProperty('state', 'error' if failed else '')
            widget.style().unpolish(widget)
            widget.style().polish(widget)

    def error_dialog(self, title, message):
        dialog = QMessageBox(QMessageBox.Icon.Warning, tr(title), tr(message), parent=self)
        dialog.setStyleSheet('QLabel { color: #ff6b6b; }')
        dialog.exec()

    def reset_checks(self):
        self.check_results.clear()
        self.check_panel.clear()
        self.check_panel.hide()

    @staticmethod
    def saved_root_reinstall(store, profile):
        try:
            return store.root_reinstall(profile)
        except LocalRecoveryError:
            return None  # The normal connection picker explains unreadable profile data.

    def home(self):
        self.ssh_command_result = None
        self.reset_checks()
        self.recovery_profile = None
        self.selected_profile = None
        self.reinstalling_root = False
        self.doctor_result = None
        self.install_settings_current = {}
        self.debloat_results = {}
        self.recovery_plan = None
        self.failure_help = None
        self.preparation = []
        self.collect_preparation = False
        self.reset_details()
        self.clear_form()
        self.preview.show()
        self.content.show()
        self.subtitle.show()
        self.steps.show()
        self.progress.hide()
        self.update_steps()
        self.set_error_state(False)
        self.badge.setText(tr('Before you begin'))
        self.rail_title.setText(tr('Set up my TV'))
        for label, title in zip(self.step_names, ('Connect to your TV', 'Choose your edition', 'Prepare the TV connection', 'Review and install', debloat.TITLE, 'Set up your Clean Your TV')):
            label.setText(tr(title))
        payload_ready = True
        try:
            if getattr(sys, 'frozen', False):
                package.check_payload_files(cli.payload_dir())
        except (OSError, ValueError):
            payload_ready = False
        if payload_ready:
            self.rail_note.setText(tr('Keep your TV on and watch for a pairing request.'))
            self.title.setText(tr('Make your TV feel like yours'))
            self.subtitle.setText(tr('Install Root or No-root. We will help you choose.'))
            self.content.setHtml('<h3>' + html.escape(tr('Before you begin')) + '</h3><p>' + html.escape(tr('Turn on your LG webOS TV and connect it to the same home network as this computer.')) + '</p><p>' + html.escape(tr('cytv will look for your TV automatically. Keep the remote nearby to approve pairing on the TV.')) + '</p>')
        else:
            self.rail_note.clear()
            self.title.setText(tr('Could not start this operation'))
            self.subtitle.setText(tr('Installation has not started.'))
            self.content.setPlainText(tr('Use a complete installer build.'))
        self.reading.verticalScrollBar().setValue(0)
        store = Store()
        reinstalls = [profile for profile in store.profiles(on_profile_error=lambda _: None)
                      if self.saved_root_reinstall(store, profile)]
        if payload_ready and reinstalls:
            if len(reinstalls) == 1:
                self.offer_root_reinstall(reinstalls[0])
            else:
                targets = Select()
                targets.setAccessibleName(tr('Choose a saved TV'))
                for profile in reinstalls:
                    targets.addItem(f"{profile['host']}:{profile['port']}", profile)
                self.form_layout.addWidget(targets)
                self.button('Continue Root reinstallation', lambda: self.start(
                    'install', targets.currentData(), resume_root_reinstall=True), True)
        setup = self.button('Set up my TV', lambda: self.start('install'), not reinstalls)
        setup.setObjectName('setupTV')
        setup.setEnabled(payload_ready)
        self.form_layout.addSpacing(6)
        secondary = QWidget()
        secondary.setObjectName('homeSecondaryActions')
        secondary_layout = QHBoxLayout(secondary)
        secondary_layout.setContentsMargins(0, 0, 0, 0)
        secondary_layout.setSpacing(12)
        self.wallpapers_button = self.button('Wallpapers', self.open_wallpapers, layout=secondary_layout)
        self.maintenance_toggle = self.button('Maintenance action', self.toggle_maintenance, layout=secondary_layout)
        self.maintenance_toggle.setObjectName('maintenanceToggle')
        self.maintenance_toggle.setCheckable(True)
        self.maintenance_toggle.setText(tr('Maintenance action') + '  ▸')
        self.diagnostics_toggle = self.button('Diagnostics', self.toggle_diagnostics, layout=secondary_layout)
        self.diagnostics_toggle.setObjectName('diagnosticsToggle')
        self.diagnostics_toggle.setCheckable(True)
        self.diagnostics_toggle.setText(tr('Diagnostics') + '  ▸')
        self.form_layout.addWidget(secondary)
        self.maintenance = QWidget()
        self.maintenance.setObjectName('maintenanceActions')
        maintenance_layout = QVBoxLayout(self.maintenance)
        maintenance_layout.setContentsMargins(16, 16, 16, 16)
        maintenance_layout.setSpacing(10)
        actions = Select()
        actions.setAccessibleName(tr('Maintenance action'))
        for label, command in MAINTENANCE_ACTIONS:
            actions.addItem(tr(label), command)
        help_text = QLabel(tr('Check TV status shows what is installed. Return to LG Home restores the standard screen. Uninstall Clean Your TV removes the CYTV apps.'))
        help_text.setWordWrap(True)
        maintenance_layout.addWidget(help_text)
        maintenance_layout.addWidget(actions)
        new_attempt = QCheckBox(tr('Start a new audited attempt after the previous deadline'))
        new_attempt.hide()

        def update_recovery_option():
            new_attempt.setChecked(False)
            new_attempt.setVisible(actions.currentData() == 'recover-system-rollback')

        actions.currentIndexChanged.connect(update_recovery_option)
        maintenance_layout.addWidget(new_attempt)
        execute = QPushButton(tr('Run selected maintenance action'))
        execute.setMinimumHeight(44)
        execute.clicked.connect(lambda: self.start(actions.currentData(), new_recovery_attempt=new_attempt.isChecked()))
        maintenance_layout.addWidget(execute)
        self.form_layout.addWidget(self.maintenance)
        self.maintenance.hide()
        self.diagnostics_actions = QWidget()
        self.diagnostics_actions.setObjectName('maintenanceActions')
        actions_layout = QVBoxLayout(self.diagnostics_actions)
        actions_layout.setContentsMargins(16, 16, 16, 16)
        for label, command in DIAGNOSTIC_ACTIONS:
            self.button(label, lambda checked=False, selected=command: self.start(selected), layout=actions_layout)
        self.form_layout.addWidget(self.diagnostics_actions)
        self.diagnostics_actions.hide()

    def open_wallpapers(self):
        if self.running:
            return
        existing = getattr(self, 'wallpaper_dialog', None)
        if existing is not None and existing.isVisible():
            existing.raise_()
            return
        self._wallpaper_closing = False
        from cytv.wallpaper_gui import WallpaperDialog
        self.wallpaper_dialog = WallpaperDialog(self)
        self.wallpaper_dialog.open()

    def toggle_maintenance(self):
        if self.maintenance_toggle.isChecked():
            self.diagnostics_toggle.setChecked(False)
        self.show_home_actions()

    def toggle_diagnostics(self):
        if self.diagnostics_toggle.isChecked():
            self.maintenance_toggle.setChecked(False)
        self.show_home_actions()

    def show_home_actions(self):
        maintenance = self.maintenance_toggle.isChecked()
        diagnostics = self.diagnostics_toggle.isChecked()
        self.preview.setVisible(not (maintenance or diagnostics))
        self.content.setVisible(not (maintenance or diagnostics))
        self.maintenance.setVisible(maintenance)
        self.diagnostics_actions.setVisible(diagnostics)
        self.maintenance_toggle.setText(tr('Maintenance action') + ('  ▾' if maintenance else '  ▸'))
        self.diagnostics_toggle.setText(tr('Diagnostics') + ('  ▾' if diagnostics else '  ▸'))

    def toggle_details(self, expanded):
        self.details.setVisible(expanded)
        self.details_toggle.setText(tr('Details') + ('  ▾' if expanded else '  ▸'))
        if expanded:
            QTimer.singleShot(0, self, self.reveal_details)
        else:
            self.reading.verticalScrollBar().setValue(0)

    def reveal_details(self):
        if self.details_toggle.isChecked():
            self.reading.verticalScrollBar().setValue(self.details.y())

    def progress_scroll_position(self):
        return max(0, self.content.y() + self.content.height() - self.reading.viewport().height())

    def follow_progress(self):
        if self.running and not self.details_toggle.isChecked():
            self.reading.verticalScrollBar().setValue(self.progress_scroll_position())

    def reset_details(self):
        self.details.setHtml('<h3>' + html.escape(tr('Details')) + '</h3>')
        self.details_toggle.setChecked(False)
        self.toggle_details(False)
        self.details_toggle.hide()

    def guide_path(self, name):
        if name not in ('sign-in', 'dev-mode', 'key-server'):
            return None
        for directory in (cli.payload_dir() / 'setup-guide',
                          Path(__file__).resolve().parents[1] / 'android/app/src/main/assets/ui/guide'):
            path = directory / (name + '.png')
            if path.is_file():
                return path
        return None

    def show_reference(self, name):
        path = self.guide_path(name)
        if path is None:
            return
        dialog = QDialog(self)
        dialog.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        dialog.setWindowTitle(tr('Example from LG'))
        layout = QVBoxLayout(dialog)
        picture = QLabel()
        picture.setAccessibleName(tr('Example from LG'))
        picture.setPixmap(QPixmap(str(path)).scaled(760, 430, Qt.AspectRatioMode.KeepAspectRatio,
                                                   Qt.TransformationMode.SmoothTransformation))
        picture.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(picture)
        caption = QLabel(tr('Example from LG. The screen may look different on your TV. Use the code shown on your own TV.'))
        caption.setWordWrap(True)
        layout.addWidget(caption)
        close = QPushButton(tr('Close'))
        close.clicked.connect(dialog.close)
        layout.addWidget(close)
        dialog.open()

    def instruction_card(self, title, messages, image=None):
        paragraphs = ''.join('<p style="margin-top: 4px; margin-bottom: 0; line-height: 125%">' + html.escape(tr(text)).replace('\n', '<br>') + '</p>' for text in messages)
        path = self.guide_path(image)
        if path is not None:
            picture = QPixmap(str(path))
            width = 240
            height = round(width * picture.height() / max(1, picture.width()))
            paragraphs = ('<table width="100%" cellpadding="6"><tr><td valign="top" width="250">'
                          '<a href="guide:' + image + '"><img src="' + QUrl.fromLocalFile(str(path)).toString() +
                          f'" width="{width}" height="{height}" alt="' + html.escape(tr('Example from LG')) + '"></a><p style="font-size: 13px">' +
                          html.escape(tr('Example from LG')) + ' · <a style="color: #d6c5ae" href="guide:' + image + '">' +
                          html.escape(tr('Enlarge')) + '</a></p></td><td valign="top">' + paragraphs + '</td></tr></table>')
        return ('<table width="100%" cellspacing="0" cellpadding="12" '
                'style="background-color: #272521; border: 1px solid #51483e"><tr><td>'
                '<h3 style="color: #f3ede3; margin-top: 0; margin-bottom: 6px">' + html.escape(tr(title)) + '</h3>' + paragraphs + '</td></tr></table>')

    def show_preparation(self, index, prompt):
        if index == len(self.preparation):
            self.preparation = []
            self.content.setHtml(self.review_content)
            self.title.setText(self.review_title)
            self.update_steps(self.preparation_return_step)
            self.badge.setText(tr(f'Step {self.current_step} of 6'))
            self.show_prompt(prompt)
            return
        self.clear_form()
        self.title.setText(tr('Prepare the TV connection'))
        self.badge.setText(tr('Step 3 of 6') + f' · {index + 1} / {len(self.preparation)}')
        self.update_steps(3)
        title, messages = self.preparation[index]
        image = {'1. Developer Mode': 'sign-in', '2. Dev Mode Status': 'dev-mode',
                 '3. Key Server': 'key-server'}.get(title)
        self.content.setHtml(self.instruction_card(title, messages, image))
        if index:
            self.button('Back', lambda: self.show_preparation(index - 1, prompt))
        self.button('Continue', lambda: self.show_preparation(index + 1, prompt), True).setFocus()

    def show_root_reinstall_restart(self):
        title = 'The TV still needs a full restart' if self.checking_saved_reinstall else 'Restart the TV to finish removal'
        self.title.setText(tr(title))
        self.badge.setText(tr(title))
        self.subtitle.setText(tr(self.recovery_plan['next_step']))
        self.rail_note.setText(tr(title))
        self.content.hide()
        self.check_panel.hide()
        self.offer_root_reinstall(dict(self.selected_profile), after_restart=True).setFocus()
        if self.report:
            self.button('Save diagnostic report…', self.save_report)
        self.button('Back to start', self.home)

    def offer_root_reinstall(self, profile, *, after_restart=False):
        label = 'I restarted the TV — check and continue' if after_restart else 'Continue Root reinstallation'
        return self.button(label,
                           lambda: self.start('install', profile, resume_root_reinstall=True), True)

    def start(self, command, profile=None, *, new_recovery_attempt=False, reconnect_after_reset=False,
              resume_root_reinstall=False, removal_operation=None, removal_pin=None):
        if getattr(getattr(self, 'wallpaper_dialog', None), 'busy', False):
            return
        if self.running:
            return
        self.running = True
        self.reset_checks()
        self.set_error_state(False)
        self.command = command
        self.operation_title = next((label for label, key in MAINTENANCE_ACTIONS + DIAGNOSTIC_ACTIONS
                                     if key == command), 'Set up my TV')
        self.preview.hide()
        self.subtitle.show()
        self.steps.setVisible(command == 'install')
        self.update_steps(1)
        self.badge.setText(tr('Connecting to your TV' if command == 'install' else 'Diagnostics' if command == 'ssh-command' else 'Maintenance action'))
        self.rail_title.setText(tr('Uninstall Clean Your TV' if removal_operation else self.operation_title))
        self.language.setEnabled(False)
        self.report = None
        self.ssh_command_result = None
        self.recovery_profile = None
        self.selected_profile = None
        self.reinstalling_root = resume_root_reinstall
        self.checking_saved_reinstall = resume_root_reinstall
        self.reconnecting_after_reset = reconnect_after_reset
        self.removal_operation = removal_operation
        self.doctor_result = None
        self.install_settings_current = {}
        self.debloat_results = {}
        self.recovery_plan = None
        self.failure_help = None
        self.pending = None
        self.preparation = []
        self.collect_preparation = False
        self.reset_details()
        self.content.clear()
        self.content.show()
        self.clear_form()
        self.title.setText(tr('Connecting to your TV' if command == 'install' else self.operation_title))
        self.subtitle.setText(tr('Keep your TV on and watch for a pairing request.'))
        self.cancel.setText(tr('Cancel'))
        self.cancel.setEnabled(False)
        self.progress.show()
        self.channel = Channel(self.events.event.emit)
        def work():
            try:
                args = [command, '--report'] if command == 'doctor' else [command]
                if resume_root_reinstall:
                    args.append('--resume-root-reinstall')
                if removal_operation is not None:
                    args.extend(['--removal-operation', removal_operation])
                if removal_pin is not None:
                    args.extend(['--removal-pin', removal_pin])
                if reconnect_after_reset:
                    args.append('--reconnect-after-reset')
                if command == 'recover-system-rollback' and new_recovery_attempt:
                    args.append('--new-recovery-attempt')
                if profile:
                    args += ['--host', profile['host'], '--edition', profile['edition'],
                             '--port', str(profile['port']), '--no-discovery']
                    for field in ('connection', 'root_variant'):
                        if profile.get(field):
                            args += ['--'+field.replace('_','-'), profile[field]]
                    if profile.get('identity'):
                        args += ['--identity', profile['identity']]
                args += ['--language', i18n.language_choice()]
                code = self.run(args, ask=self.channel.ask, secret=self.channel.secret, write=self.channel.console)
            except Exception:
                # Startup/storage errors outside cli.main's handler must stay visible,
                # without exposing exception text that could contain credentials.
                self.events.event.emit('error-heading', 'Could not start this operation')
                self.events.event.emit('error', 'Check that your user account can write to its application data folder. You can report this problem using Open an issue below.')
                code = 1
            self.events.event.emit('done', code)
        self.worker = threading.Thread(target=work, name='cytv-install', daemon=False)
        self.worker.start()

    def receive(self, kind, value):
        if kind == 'removal-reconnect':
            stop, result = value
            if self.removal_watch is stop:
                self.finish_removal_watch(result)
        elif kind == 'root-reinstall':
            self.reinstalling_root = True
            self.rail_title.setText(tr('Reinstall Root using this installer'))
        elif kind == 'ssh-command-result':
            self.ssh_command_result = value
        elif kind == 'debloat-results':
            self.debloat_results = dict(value)
        elif kind == 'installation-settings':
            self.install_settings_current = {key:value[key] for key in ('renewal','block_updates') if type(value.get(key)) is bool}
            if isinstance(value.get('tv_name'), str):
                self.install_settings_current['tv_name'] = value['tv_name']
        elif kind == 'check':
            self.check_panel.setAccessibleName(tr('TV checks'))
            self.check_results[value['id']] = dict(value)
            from .checks import STATUS
            colors = {'pass': '#90cfad', 'fail': '#ff8580', 'unknown': '#e8c17d',
                      'running': '#eddbc2', 'pending': '#c0b5a5'}
            rows = []
            priority = {'packages':0, 'startup':1, 'home-button':2}
            for result in sorted(self.check_results.values(), key=lambda item: priority.get(item['id'],3 if item['status'] in ('fail','unknown') else 4)):
                status = result['status']
                label, detail = html.escape(tr(result['label'])), html.escape(tr(result['detail']))
                marker = {'pass': '✓', 'fail': '!', 'unknown': '?', 'running': '…', 'pending': '·'}[status]
                rows.append(f'<tr><td width="24" valign="top" style="color:{colors[status]};padding:5px">{marker}</td>'
                            f'<td style="padding:5px">{label}' + (f'<br><small>{detail}</small>' if detail else '') + '</td>'
                            f'<td style="color:{colors[status]};padding:5px">{html.escape(tr(STATUS[status]))}</td></tr>')
            self.check_panel.setHtml('<h3>' + html.escape(tr('TV checks')) + '</h3><table width="100%">' + ''.join(rows) + '</table>')
            self.check_panel.show()
        elif kind == 'step':
            number, title, clear = value
            self.collect_preparation = number == 3
            if self.collect_preparation:
                self.preparation = []
            self.details.append(html.escape(tr(title)))
            if self.command == 'install':
                self.title.setText(tr(title))
                self.subtitle.hide()
                self.badge.setText(tr(f'Step {number} of 6'))
                self.update_steps(number)
            else:
                self.title.setText(tr(self.operation_title))
                self.subtitle.setText(tr(title))
                self.subtitle.show()
                self.badge.setText(tr('Maintenance action'))
            self.content.clear()
            self.reading.verticalScrollBar().setValue(0)
        elif kind in ('text', 'heading', 'error', 'error-heading'):
            text = tr(value)
            tag = 'h3' if kind in ('heading', 'error-heading') else 'p'
            color = '#ff6b6b' if kind.startswith('error') else '#f3ede3' if kind == 'heading' else '#c0b5a5'
            style = f' style="color: {color}"'
            markup = f'<{tag}{style}>' + html.escape(text).replace('\n', '<br>') + f'</{tag}>'
            scroll = self.reading.verticalScrollBar()
            if self.running and scroll.value() == self.progress_scroll_position():
                QTimer.singleShot(0, self, self.follow_progress)
            self.content.append(markup)
            if kind.startswith('error'):
                self.content.document().lastBlock().setUserState(1)
            self.details.append(markup)
            self.details_toggle.show()
            if self.collect_preparation:
                if kind == 'heading':
                    self.preparation.append((value, []))
                elif kind == 'text' and self.preparation:
                    self.preparation[-1][1].append(value)
        elif kind == 'report':
            path = Path(value)
            if path.is_file():
                self.report = path
        elif kind == 'doctor-result':
            self.doctor_result = dict(value)
            self.details.append('<pre>' + html.escape(json.dumps(value, indent=2)) + '</pre>')
            self.details_toggle.show()
            if (value.get('pending') or value.get('active_operation')) and self.selected_profile:
                self.recovery_profile = dict(self.selected_profile)
        elif kind == 'failure-help':
            self.failure_help = dict(value)
        elif kind == 'recovery-plan':
            self.recovery_plan = dict(value)
            self.steps.hide()
            if not self.reinstalling_root and self.removal_operation is None:
                self.rail_title.setText(tr('Review recovery options'))
            from .recovery_ui import removal_details, removal_milestones
            detail = removal_details(self.recovery_plan)
            milestones = removal_milestones(self.recovery_plan)
            if detail:
                self.subtitle.setText('\n'.join(tr(text) for text in (*detail.values(), *milestones) if text))
                self.subtitle.show()
            else:
                self.subtitle.setText(tr(self.recovery_plan.get('next_step', self.recovery_plan['summary'])))
                self.subtitle.show()
                if self.running and self.command == 'recover' and self.recovery_plan['state'] == 'review':
                    # The saved cleanup stage is history until this review reads the TV.
                    self.content.clear()
        elif kind == 'recovery':
            self.recovery_profile = dict(value)
        elif kind == 'selected-profile':
            self.selected_profile = dict(value)
            self.reset_checks()
        elif kind == 'prompt':
            self.show_prompt(value)
        elif kind == 'done':
            self.running = False
            if value == 0 and self.command == 'uninstall' and self.recovery_plan is None:
                self.recovery_plan = {'state':'review', 'summary':'Removal is not verified.',
                                      'next_step':'Read the result below before continuing.'}
            self.language.setEnabled(True)
            self.pending = None
            self.progress.hide()
            self.cancel.setText(tr('Close'))
            self.cancel.setEnabled(True)
            self.clear_form()
            plan = self.recovery_plan or {}
            resume_root_reinstall = (self.reinstalling_root and self.selected_profile is not None
                                     and plan.get('disposition') != 'operation-active'
                                     and self.saved_root_reinstall(Store(), self.selected_profile))
            if (resume_root_reinstall and value == 2 and plan.get('disposition') == 'clean-removal'
                    and plan.get('state') == 'waiting' and not self.failure_help
                    and plan.get('removal_action', {}).get('condition') == 'restart'):
                self.show_root_reinstall_restart()
                return
            self.set_error_state(value not in (0, 130))
            if self.command == 'ssh-command':
                if self.ssh_command_result is not None:
                    self.show_ssh_command_result(self.ssh_command_result)
                    return
                if value == 130:
                    self.home()
                    return
            self.title.setText(tr('Finished' if value == 0 else 'Cancelled' if value == 130 else 'Let’s resolve this'))
            self.subtitle.show()
            self.subtitle.setText(tr('Read the result below before continuing.'))
            self.rail_note.setText(tr('Read the result below before continuing.'))
            self.badge.setText(self.title.text())
            if self.command == 'install' and not self.recovery_plan:
                self.update_steps(self.current_step, value)
            failed = value not in (0, 130)
            if failed:
                block = self.content.document().begin()
                while block.isValid() and block.userState() != 1:
                    block = block.next()
                if block.isValid() and block.position():
                    # Earlier progress is still available in Details.
                    cursor = QTextCursor(block)
                    cursor.movePosition(QTextCursor.MoveOperation.Start, QTextCursor.MoveMode.KeepAnchor)
                    cursor.removeSelectedText()
            self.reading.verticalScrollBar().setValue(0)
            disposition = (self.recovery_plan or {}).get('disposition')
            active_operation = disposition == 'operation-active'
            cleanup = not active_operation and (self.command == 'uninstall' or disposition == 'clean-removal')
            status_refresh = self.recovery_profile is not None and disposition in ('no-root-package-check', 'operation-active')
            completed = False
            recover = (not cleanup and self.recovery_profile is not None and
                       ((self.recovery_plan is None and
                         (value == 0 or (self.failure_help or {}).get('code') in ('removal-not-submitted','no-root-recovery'))) or
                        (self.recovery_plan is not None and self.recovery_plan.get('state') == 'review') or
                        (self.recovery_plan is not None and self.recovery_plan.get('state') != 'complete' and
                         type(self.recovery_plan.get('actions')) is list and
                         'continue-removal' in self.recovery_plan.get('actions', []))))
            if self.recovery_plan:
                from .recovery_ui import removal_restart_required
                restart = removal_restart_required(self.recovery_plan)
                completed = (value == 0 and self.recovery_plan['state'] == 'complete' and
                             not restart and
                             (self.command != 'uninstall' or self.recovery_plan.get('disposition') == 'clean-removal') and
                             (self.recovery_plan.get('disposition') != 'clean-removal' or
                              self.recovery_plan.get('verified_clean') is True and self.recovery_plan.get('removed') is True))
                self.title.setText(tr('Cancelled' if value == 130 else self.recovery_plan['summary'] if completed else 'Review recovery options'))
                self.subtitle.setText(tr(self.recovery_plan.get('next_step', '') if completed else self.recovery_plan['summary']))
                self.badge.setText(self.title.text())
            retry_removal = cleanup and not completed and self.recovery_profile is not None
            removal_reconnect = ((self.recovery_plan or {}).get('removal_reconnect')
                                 if value != 130 and retry_removal and self.command in ('uninstall', 'recover') else None)
            retry_button = None
            missing_root_connection = False
            continue_removal = (self.removal_operation if self.command == 'restore' and completed
                                and self.recovery_profile
                                and self.recovery_plan.get('continue_removal') == self.removal_operation else None)
            restore_for_removal = (self.recovery_plan.get('restore_for_removal')
                                   if retry_removal and value not in (0, 130)
                                   and self.command in ('uninstall', 'recover') else None)
            doctor_ready = (value == 0 and self.command == 'doctor' and self.doctor_result is not None
                            and self.selected_profile is not None and not self.recovery_plan and not recover)
            home_failed = self.check_results.get('home-button', {}).get('status') == 'fail'
            setup_review = False
            if value == 0 and not self.recovery_plan and 'packages' in self.check_results:
                confirmed = all(self.check_results.get(key, {}).get('status') == 'pass'
                                for key in ('packages', 'startup', 'home-button'))
                setup_review = not confirmed
                self.title.setText(tr('Home button confirmed by you' if confirmed else 'Review TV checks'))
                self.subtitle.setText(tr('Package verification, startup readback and your Home-button observation are separate results.'))
                self.badge.setText(self.title.text())
            if resume_root_reinstall:
                profile = dict(self.selected_profile)
                self.offer_root_reinstall(profile)
                if (self.failure_help or {}).get('code', '').startswith('ssh-'):
                    self.button('Connection details', lambda: self.edit_connection(profile, removal=True, reinstall=True))
                elif recover or (retry_removal and self.recovery_plan.get('state') == 'blocked'):
                    self.button('Review recovery options', lambda: self.start('recover', profile))
            elif recover:
                profile = dict(self.recovery_profile)
                self.title.setText(tr('Cancelled' if value == 130 else 'Review recovery options'))
                self.badge.setText(self.title.text())
                self.subtitle.setText(tr('Checking recovery does not reinstall or remove packages. Root checks may run verified support code.'))
                self.button('Review recovery options', lambda: self.start('recover', profile), not failed)
            elif status_refresh:
                profile = dict(self.recovery_profile)
                self.title.setText(tr(self.recovery_plan['summary']))
                self.badge.setText(self.title.text())
                self.subtitle.setText(tr(self.recovery_plan['next_step']))
                self.button('Check TV status', lambda: self.start('status', profile), True)
            elif continue_removal:
                profile = dict(self.recovery_profile)
                self.button('Continue removal', lambda: self.start('uninstall', profile,
                            removal_operation=continue_removal), True)
            elif doctor_ready:
                self.show_doctor_success()
            elif completed and cleanup and self.recovery_profile is not None:
                profile = dict(self.recovery_profile)
                self.button('Set up my TV', lambda: self.start('install', profile))
            elif retry_removal:
                profile = dict(self.recovery_profile)
                from .recovery_ui import removal_action, projected_removal_action
                advice = (removal_action(self.recovery_plan, self.failure_help) if self.failure_help
                          else projected_removal_action(self.recovery_plan))
                if restore_for_removal:
                    self.rail_title.setText(tr('Uninstall Clean Your TV'))
                    self.button('Return to LG Home', lambda: self.start('restore', profile,
                                removal_operation=restore_for_removal), True)
                    self.button('Review recovery options', lambda: self.start('recover', profile))
                elif self.command == 'restore' and advice['action'] == 'retry-removal':
                    self.button('Try again', lambda: self.start('restore', profile,
                                removal_operation=self.removal_operation), True)
                elif self.command == 'restore':
                    self.button('Review recovery options', lambda: self.start('recover', profile), True)
                elif advice['action'] == 'connect-root' and profile['edition'] == 'root':
                    self.button('Connection details', lambda: self.edit_connection(profile, removal=True), True)
                elif advice['action'] == 'connect-root':
                    from .recovery_ui import root_removal_profile
                    saved_root = root_removal_profile(Store(), profile)
                    if saved_root is not None:
                        root_profile, root_pin = saved_root
                        self.button('Connect using Root',
                                    lambda: self.start('uninstall', root_profile, removal_pin=root_pin), True)
                    else:
                        missing_root_connection = True
                        self.button('Review recovery options', lambda: self.start('recover', profile), True)
                elif advice['action'] == 'retry-removal':
                    operation = removal_reconnect['operation'] if removal_reconnect else self.removal_operation
                    pin = removal_reconnect['pin'] if removal_reconnect else None
                    retry_button = self.button('Try again', lambda: self.start('uninstall', profile,
                                              removal_operation=operation, removal_pin=pin), True)
                else:
                    self.button('Review recovery options', lambda: self.start('recover', profile), True)
                from .recovery_ui import removal_connection_failure
                if removal_connection_failure(self.recovery_plan, self.failure_help):
                    self.button('Connection details', lambda: self.edit_connection(profile, removal=True))
            elif (value == 0 and (not self.recovery_plan or completed) and self.selected_profile
                  and home_failed and self.check_results.get('packages', {}).get('status') == 'pass'):
                profile = dict(self.selected_profile)
                if profile['edition'] == 'no-root':
                    self.button('Home button diagnostics', self.show_reported_home_result)
                else:
                    self.button('Check TV status', lambda: self.start('status', profile))
            connection_help = (failed and self.failure_help and self.failure_help.get('can_edit_connection')
                               and self.failure_help['code'].startswith(('ssh-', 'developer-key-'))
                               and self.selected_profile and not self.recovery_plan and not self.recovery_profile
                               and not resume_root_reinstall)
            if connection_help:
                profile = dict(self.selected_profile)
                self.button('Check connection again', lambda: self.start('doctor', profile), True)
                actions = QHBoxLayout()
                self.form_layout.addLayout(actions)
                if sys.platform == 'darwin' and self.failure_help['code'] in ('ssh-access-denied', 'ssh-unreachable', 'ssh-timeout'):
                    self.button('Open System Settings', self.open_network_settings, layout=actions)
                self.button('Change connection', lambda: self.edit_connection(profile), layout=actions)
            retry_local_storage = (failed and self.command == 'install' and not self.reinstalling_root
                                   and not self.recovery_plan and not self.recovery_profile
                                   and (self.failure_help or {}).get('can_retry_setup'))
            if retry_local_storage:
                profile = dict(self.selected_profile) if self.selected_profile else None
                retry_options = {'reconnect_after_reset': True} if self.reconnecting_after_reset and profile else {}
                self.button('Try again', lambda: self.start('install', profile, **retry_options), True)
            if failed and self.failure_help and self.failure_help.get('can_reconnect_after_reset') and self.selected_profile:
                reset_profile = dict(self.selected_profile)
                self.button('Reconnect after factory reset',
                            lambda: self.start('install', reset_profile, reconnect_after_reset=True))
            report_actions = None
            if connection_help or (retry_removal and self.report):
                report_actions = QHBoxLayout()
                self.form_layout.addLayout(report_actions)
            if self.report:
                save_report = self.button('Save diagnostic report…', self.save_report,
                                          (failed or setup_review) and not retry_removal and not connection_help
                                          and not resume_root_reinstall and not status_refresh and not retry_local_storage,
                                          layout=report_actions)
                save_report.setObjectName('resultReport')
                if failed and not status_refresh:
                    self.subtitle.setText(tr('Save the report from this failed attempt and attach it to your issue. Recovery data has been kept.'))
            elif failed and not status_refresh:
                self.subtitle.setText(tr('A diagnostic report could not be created. Include the visible error when opening an issue.'))
            if (failed and not active_operation) or home_failed:
                self.button('Open an issue', self.show_issue_draft,
                            layout=report_actions if connection_help else None)
            self.button('Back to start', self.home,
                        not doctor_ready and not connection_help and not retry_removal and not recover
                        and not continue_removal and not resume_root_reinstall and not status_refresh and not retry_local_storage
                        and not ((failed or setup_review) and self.report),
                        layout=report_actions if retry_removal else None)
            failed_checks = [result for result in self.check_results.values() if result['status'] in ('fail', 'unknown')]
            if failed and failed_checks:
                self.subtitle.setText(tr('Failed') + ': ' + ', '.join(tr(result['label']) for result in failed_checks) + '\n' + self.subtitle.text())
            if failed and self.failure_help:
                if not self.recovery_plan:
                    self.title.setText(tr(self.failure_help['title']))
                    self.badge.setText(self.title.text())
                messages = [self.failure_help['next_step']]
                if self.failure_help['code'] in ('root-home-unsupported', 'root-home-unconfirmed'):
                    messages.insert(0, self.failure_help['detail'])
                self.subtitle.setText('\n'.join(tr(message) for message in messages))
                if not self.report and not active_operation:
                    self.subtitle.setText(self.subtitle.text()+'\n'+tr('A diagnostic report could not be created. Include the visible error when opening an issue.'))
            if self.recovery_plan:
                from .recovery_ui import removal_details, removal_connection_failure, removal_milestones, removal_title, removal_waiting
                detail = removal_details(self.recovery_plan, self.failure_help)
                connection = removal_connection_failure(self.recovery_plan, self.failure_help)
                show_restart = restart and not connection
                if cleanup and not completed:
                    self.title.setText(tr('Cancelled' if value == 130 else removal_title(self.recovery_plan, self.failure_help)))
                    if removal_waiting(self.recovery_plan, self.failure_help):
                        self.set_error_state(False)
                    self.badge.setText(self.title.text())
                    message = detail.get('blocker_text') or 'Removal could not be verified. Review recovery options before continuing.'
                    if restore_for_removal:
                        message = 'Restore LG Home before continuing removal.'
                    elif missing_root_connection:
                        message = 'Without existing Root access, cleanup remains incomplete. Keep the recovery data.'
                    if self.failure_help and self.failure_help.get('code') in ('ssh-auth-root','ssh-auth-no-root','ssh-key-file','ssh-identity','developer-key-server','developer-key-unlock','developer-key-response'):
                        message = self.failure_help['next_step']
                    self.subtitle.setText(tr(message)+('' if show_restart or connection else '\n'+tr(detail.get('stage_text', ''))))
                milestones = removal_milestones(self.recovery_plan, self.failure_help)
                if milestones:
                    self.subtitle.setText('\n'.join((self.subtitle.text(), *(tr(text) for text in milestones))))

            if connection_help:
                self.subtitle.setText(tr(self.failure_help['detail']))
                if not self.report:
                    self.subtitle.setText(self.subtitle.text()+'\n'+tr('A diagnostic report could not be created. Include the visible error when opening an issue.'))
                messages = [self.failure_help['next_step']]
                if sys.platform == 'darwin' and self.failure_help['code'] in ('ssh-access-denied', 'ssh-unreachable', 'ssh-timeout'):
                    # macOS can retain an older duplicate's display name. The socket
                    # error alone does not establish the Local Network switch state.
                    app = next((p.name for p in Path(sys.executable).parents if p.suffix == '.app'), 'cytv')
                    mac_help = tr('In System Settings → Privacy & Security → Local Network, allow {app}. macOS may show an older copy’s name. Fully quit cytv and reopen it after changing access.').format(app=app)
                    messages = [mac_help] if self.failure_help['code'] == 'ssh-access-denied' else [*messages, mac_help]
                self.content.setHtml(''.join('<p>'+html.escape(tr(message))+'</p>' for message in messages))
                self.content.moveCursor(self.content.textCursor().MoveOperation.Start)
                self.check_panel.hide()

            if removal_reconnect and retry_button is not None:
                self.watch_removal_tv(profile, removal_reconnect, retry_button)
            else:
                # QMainWindow buttons need focus for Return to activate the default.
                default_action = next((button for button in self.form.findChildren(QPushButton)
                                       if button.isDefault()), None)
                if default_action is not None:
                    default_action.setFocus()

    def watch_removal_tv(self, profile, reconnect, retry_button):
        from .recovery import wait_for_removal_tv

        stop = self.removal_watch = threading.Event()
        self.removal_retry_button = retry_button
        self.running = True
        self.form.setEnabled(False)
        self.language.setEnabled(False)
        self.progress.show()
        self.cancel.setText(tr('Cancel'))
        self.subtitle.setText(tr('Disconnect the TV from power, reconnect it, and turn it on. Standby is not a full restart.')
                              + '\n' + tr('Waiting for the same TV to come back online…'))
        deadline = monotonic() + REMOVAL_RECONNECT_SECONDS

        def work():
            result = wait_for_removal_tv(Store(), profile, reconnect, stop, deadline)
            if not stop.is_set():
                self.events.event.emit('removal-reconnect', (stop, result))

        QTimer.singleShot(int(1000 * REMOVAL_RECONNECT_SECONDS), self,
                          lambda: self.finish_removal_watch('timeout') if self.removal_watch is stop else None)
        self.worker = threading.Thread(target=work, name='cytv-removal-watch', daemon=True)
        self.worker.start()

    def finish_removal_watch(self, result):
        self.removal_watch.set()
        self.removal_watch = None
        self.running = False
        self.form.setEnabled(True)
        self.language.setEnabled(True)
        self.progress.hide()
        self.cancel.setText(tr('Close'))
        if result == 'ready':
            self.removal_retry_button.setText(tr('Continue removal'))
            self.title.setText(tr('Connected to your TV'))
            self.subtitle.setText(tr('The TV is online. Choose Continue removal to check the remaining cleanup.'))
        else:
            self.title.setText(tr('Cancelled' if result == 'cancelled' else 'Check the TV connection to continue removal'))
            message = tr('Check the TV connection, then choose Try again.')
            if result == 'identity':
                message = (tr('The original saved TV connection and host key are required for recovery.')
                           + ' ' + tr('Recovery data was kept.'))
            self.subtitle.setText(message)
        self.badge.setText(self.title.text())
        self.removal_retry_button.setFocus()
        self.removal_retry_button = None

    def show_doctor_success(self):
        """Offer the normal setup path; its installation/recovery gates still apply."""
        result = self.doctor_result
        device = result.get('device', {})
        state = diagnostics.context.status_summary(result)
        stage = state.get('deployment_stage')
        if stage == 'installed-recovery-only' and state.get('home_enabled') is False:
            message = 'A previous Clean Your TV installation was found, but its Home control is off.'
        elif stage == 'installed-recovery-only' and state.get('home_enabled') is True:
            message = 'A previous Clean Your TV installation was found. Home control is enabled.'
        elif device.get('apps'):
            message = 'Clean Your TV components were found on this TV.'
        elif stage in ('absent', 'uninstalled-state-retained'):
            message = 'Ready to set up Clean Your TV.'
        else:
            message = 'Setup will check the existing installation before continuing.'
        self.title.setText(tr('Connected to your TV'))
        self.badge.setText(self.title.text())
        self.subtitle.setText(tr('Continue setup using the same TV connection and edition.'))
        self.rail_title.setText(tr('Set up my TV'))
        self.rail_note.setText(tr('Connection checked. Continue to review setup.'))
        self.content.setHtml(''.join('<p>' + html.escape(tr(text)) + '</p>' for text in (
            message, 'Setup will check installed versions and ask before making changes.')))
        self.check_panel.hide()
        self.details_toggle.setChecked(False)
        self.details.hide()
        profile = dict(self.selected_profile)
        self.button('Continue setup', lambda: self.start('install', profile), True)

    def open_network_settings(self):
        try:
            subprocess.Popen(['open', '-b', 'com.apple.systempreferences'])
        except OSError:
            self.error_dialog('Open System Settings', self.failure_help['next_step'])

    def edit_connection(self, profile, removal=False, *, reinstall=False):
        """Keep recovery targets fixed while allowing an existing SSH credential."""
        from .recovery_ui import removal_action, projected_removal_action
        advice = (removal_action(self.recovery_plan, self.failure_help) if self.failure_help
                  else projected_removal_action(self.recovery_plan or {})) if removal else {}
        resume_command = 'recover'
        if reinstall:
            resume_command = 'install'
        elif advice.get('action') == 'retry-removal':
            resume_command = 'restore' if self.command == 'restore' else 'uninstall'
        bound_removal = self.removal_operation if resume_command in ('restore', 'uninstall') else None
        self.clear_form()
        self.set_error_state(False)
        self.title.setText(tr('Connection details'))
        self.subtitle.setText(tr('Review the selected edition and SSH port against your existing trusted access. Do not weaken SSH security or disable host verification.'))
        if removal and self.failure_help:
            self.subtitle.setText(tr(self.failure_help['next_step']))
        self.content.hide()
        self.steps.hide()
        self.check_panel.hide()
        address, port = QLineEdit(profile['host']), QLineEdit(str(profile['port']))
        edition = Select()
        for key in ('root', 'no-root'):
            edition.addItem('Root' if key == 'root' else 'No-root', key)
        edition.setCurrentIndex(0 if profile['edition'] == 'root' else 1)
        if removal:
            address.setReadOnly(True)
            port.setReadOnly(True)
            edition.setEnabled(False)
        for text, control in [('TV IPv4 address or hostname', address), ('Edition', edition),
                              ('SSH port (No-root: 9922; Root: 22)', port)]:
            label = QLabel(tr(text))
            label.setBuddy(control)
            control.setAccessibleName(label.text())
            self.form_layout.addWidget(label)
            self.form_layout.addWidget(control)
        def reconnect(edited):
            if reinstall:
                self.start('install', edited, resume_root_reinstall=True)
            else:
                self.start(resume_command if removal else 'doctor', edited, removal_operation=bound_removal)

        def check():
            from .state import target
            try:
                options = {key: profile[key] for key in ('connection', 'root_variant')
                           if key in profile and edition.currentData() == profile['edition']}
                edited = target(address.text(), edition.currentData(), port.text(), **options)
            except ValueError:
                self.subtitle.setText(tr('Invalid TV address or port. Use an IPv4 address or hostname and a port from 1 to 65535.'))
                return
            reconnect(edited)
        if removal and (profile['edition'] == 'root' or profile.get('connection') == 'root-ssh'):
            def choose_key():
                filename, _ = QFileDialog.getOpenFileName(self, tr('Choose your existing SSH private key'))
                if filename:
                    reconnect(dict(profile, identity=filename))
            self.button('Choose key file…', choose_key)
        label = {'install':'Continue Root reinstallation', 'uninstall':'Try again', 'restore':'Try again',
                 'recover':'Review recovery options'}[resume_command] if removal else 'Check connection again'
        self.button(label, check, True)
        self.button('Back to start', self.home)
        address.setFocus()

    def show_debloat_selection(self):
        maintenance = self.command == 'debloat'
        self.content.hide()
        self.preview.hide()
        self.title.setText(tr(debloat.TITLE))
        notice = WrappedLabel(tr(debloat.NOTICE))
        notice.setObjectName('settingHint')
        self.form_layout.addWidget(notice)
        scroll = QScrollArea()
        scroll.setObjectName('debloatSelection')
        scroll.setAccessibleName(tr(debloat.SELECT.strip().rstrip(':')))
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setMinimumHeight(200)
        panel = QWidget()
        panel.setObjectName('debloatFields')
        fields = QVBoxLayout(panel)
        fields.setContentsMargins(0, 0, 12, 0)
        fields.setSpacing(8)
        fields.setAlignment(Qt.AlignmentFlag.AlignTop)
        scroll.setWidget(panel)
        self.form_layout.addWidget(scroll, 1)
        selected = {}

        def add_group(title, rows):
            card = QFrame()
            card.setObjectName('debloatGroup')
            group_layout = QVBoxLayout(card)
            group_layout.setContentsMargins(12, 2, 8, 2)
            group_layout.setSpacing(0)
            fields.addWidget(card)
            section = ToggleSwitch(tr(title), tr('Selected'), tr('Keep current'))
            section.setObjectName('debloatGroup-' + rows[0][0])
            header = QHBoxLayout()
            heading = WrappedLabel(tr(title))
            heading.setObjectName('settingTitle')
            heading.setBuddy(section)
            header.addWidget(heading, 1)
            header.addWidget(section)
            group_layout.addLayout(header)
            switches = []
            for key, _, label, _ in rows:
                row = QHBoxLayout()
                row.setContentsMargins(14, 0, 0, 0)
                text = WrappedLabel(tr(label))
                toggle = ToggleSwitch(tr(label), tr('Selected'), tr('Keep current'))
                toggle.setObjectName('debloat-' + key)
                toggle.setChecked(not maintenance)
                text.setBuddy(toggle)
                row.addWidget(text, 1)
                row.addWidget(toggle)
                group_layout.addLayout(row)
                selected[key] = toggle
                switches.append(toggle)

            def update_group():
                count = sum(toggle.isChecked() for toggle in switches)
                section.blockSignals(True)
                section.off_text = tr('Some selected') if count else tr('Keep current')
                section.setChecked(count == len(switches))
                section.setAccessibleDescription(section.on_text if section.isChecked() else section.off_text)
                section.updateGeometry()
                section.update()
                section.blockSignals(False)

            def select_group(checked):
                for toggle in switches:
                    toggle.blockSignals(True)
                    toggle.setChecked(checked)
                    toggle.setAccessibleDescription(toggle.on_text if checked else toggle.off_text)
                    toggle.blockSignals(False)
                update_group()

            section.toggled.connect(select_group)
            for toggle in switches:
                toggle.toggled.connect(update_group)
            update_group()
            return section

        first = None
        for group, rows in debloat.GROUPS:
            section = add_group(group, rows)
            if first is None:
                first = section
        actions = QHBoxLayout()
        actions.addStretch()
        self.button('Skip Debloat', lambda: self.submit('[]'), layout=actions)
        apply = self.button(debloat.APPLY if maintenance else 'Continue', lambda: self.submit(json.dumps([
            key for key, toggle in selected.items() if toggle.isChecked()])), True, layout=actions)
        if maintenance:
            apply.setEnabled(False)
            for toggle in panel.findChildren(ToggleSwitch):
                toggle.toggled.connect(lambda: apply.setEnabled(any(item.isChecked() for item in selected.values())))
        self.form_layout.addLayout(actions)
        first.setFocus()

    def show_debloat_results(self):
        self.title.setText(tr('Debloat results'))
        self.content.show()
        rows = []
        for key, status in self.debloat_results.items():
            icon, color, message = debloat.RESULTS[status]
            label = html.escape(tr(debloat.SETTINGS[key][1]))
            message = html.escape(tr(message))
            rows.append(f'<tr><td width="32" valign="top" style="color:{color}">{icon}</td>'
                        f'<td><span style="color:#f3ede3;font-weight:600">{label}</span><br>'
                        f'<small>{message}</small></td></tr>')
        self.content.setHtml('<table width="100%" cellspacing="0" cellpadding="7">' + ''.join(rows) + '</table>')
        self.button('Continue' if self.command == 'debloat' else debloat.CONTINUE,
                    lambda: self.submit('1'), True).setFocus()

    def show_install_settings(self):
        from . import install_settings as settings
        self.title.setText(tr(settings.TITLE))
        self.content.clear()
        self.content.hide()
        self.preview.hide()
        self.subtitle.setText(tr('Clean Your TV is installed.'))
        self.subtitle.show()
        scroll = QScrollArea()
        scroll.setObjectName('installationSettings')
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setMinimumHeight(240)
        panel = QWidget()
        panel.setObjectName('installationSettingsFields')
        fields = QVBoxLayout(panel)
        fields.setContentsMargins(0, 0, 12, 0)
        fields.setSpacing(10)
        fields.setSizeConstraint(QLayout.SizeConstraint.SetMinAndMaxSize)
        scroll.setWidget(panel)
        self.form_layout.addWidget(scroll, 1)
        self.update_steps(6)
        self.badge.setText(tr('Step 6 of 6'))
        profile = self.selected_profile or {'edition': 'no-root'}
        fields.setAlignment(Qt.AlignmentFlag.AlignTop)
        name = None
        if profile['edition'] == 'root':
            name_label = QLabel(tr('Home screen name'))
            name = QLineEdit()
            name.setObjectName('tvName')
            name.setPlaceholderText(self.install_settings_current.get('tv_name', 'Home'))
            name_label.setBuddy(name)
            fields.addWidget(name_label)
            fields.addWidget(name)
            name_error = QLabel('')
            name_error.setWordWrap(True)
            name_error.setObjectName('tvNameError')
            fields.addWidget(name_error)
        fields.addWidget(QLabel(tr('Theme')))
        cards_row = QWidget()
        cards_layout = QHBoxLayout(cards_row)
        cards_layout.setContentsMargins(0, 0, 0, 0)
        cards_layout.setSpacing(12)
        group = QButtonGroup(cards_row)
        cards = []
        for key, title in settings.THEMES:
            card = ThemeCard(title, key, self.theme_preview_path(key))
            card.setObjectName('theme-' + key)
            group.addButton(card)
            cards_layout.addWidget(card, 1)
            cards.append(card)
        cards[0].setChecked(True)
        fields.addWidget(cards_row)
        fields.addSpacing(12)
        def switch_row(key, title, help_text, unchanged_text=None):
            row = QWidget()
            layout = QHBoxLayout(row)
            layout.setContentsMargins(0, 0, 0, 0)
            layout.setSpacing(16)
            label = WrappedLabel(tr(title))
            label.setObjectName('settingTitle')
            toggle = ToggleSwitch(tr(title), tr('On'), tr('Off'), unchanged_text)
            toggle.setObjectName(key)
            label.setBuddy(toggle)
            layout.addWidget(label, 1)
            layout.addWidget(toggle)
            fields.addWidget(row)
            hint = None
            if help_text:
                hint = WrappedLabel(tr(help_text))
                hint.setObjectName('settingHint')
                fields.addWidget(hint)
            return toggle, hint
        weather, _ = switch_row('weather', 'Show weather on Home', '')
        def theme_changed():
            ribbon = cards[2].isChecked()
            weather.setEnabled(not ribbon)
            if ribbon:
                weather.setChecked(False)
            weather.setToolTip(tr('Ribbon does not support weather.') if ribbon else '')
            weather.setAccessibleDescription(tr('Ribbon does not support weather.') if ribbon else tr('On' if weather.isChecked() else 'Off'))
        group.buttonToggled.connect(lambda *_:theme_changed())
        switches = {}
        current = self.install_settings_current
        feature = ('block_updates', 'Block LG firmware updates', 'We recommend restarting the TV after applying.') if profile['edition'] == 'root' else (
            ('renewal', settings.RENEWAL_TITLE, settings.RENEWAL_HELP)
            if profile.get('connection') != 'root-ssh' else None)
        if feature:
            fields.addSpacing(8)
            divider = QFrame()
            divider.setObjectName('settingsDivider')
            divider.setFixedHeight(1)
            fields.addWidget(divider)
            fields.addSpacing(8)
            key, title, help_text = feature
            toggle, hint = switch_row(key, title, help_text)
            if key in current:
                toggle.setChecked(current[key])
            else:
                toggle.setEnabled(False)
                toggle.off_text = tr('Not checked')
                toggle.setAccessibleDescription(tr('Not checked'))
                toggle.updateGeometry()
                hint.setText(tr('Current setting unavailable. Check it in Home settings.'))
            switches[key] = toggle
        usage_sort, _ = switch_row('usage_sort', settings.USAGE_SORT, settings.USAGE_SORT_HELP,
                                   tr('Keep current settings'))

        def save():
            value = {'theme': group.checkedButton().key, 'weather': weather.isChecked()}
            if usage_sort.checkState() != Qt.CheckState.PartiallyChecked:
                value['usage_sort'] = usage_sort.isChecked()
            for key, toggle in switches.items():
                if toggle.isEnabled() and toggle.isChecked() != current[key]:
                    value[key] = toggle.isChecked()
            if name is not None and name.text().strip():
                from .package import normalize_tv_name
                try:
                    value['tv_name'] = normalize_tv_name(name.text())
                except ValueError:
                    name.setFocus()
                    name_error.setText(tr('Home screen name must contain at most 48 characters, without control characters.'))
                    return
            self.submit(json.dumps(settings.validate(value, profile)))
        self.button('Continue', save, True)
        self.button('Keep current settings', lambda: self.submit('{}'))
        cards[0].setFocus()

    def theme_preview_path(self, key):
        sources = {'classic':'showcase/assets/classic-preview.png',
                   'liquid-glass':'themes/liquid-glass/assets/preview.jpg',
                   'ribbon':'themes/ribbon/assets/preview.jpg'}
        filename = key + ('.png' if key == 'classic' else '.jpg')
        packaged = cli.payload_dir() / 'setup-themes' / filename
        return packaged if packaged.is_file() else Path(__file__).resolve().parents[1] / sources[key]

    def show_prompt(self, prompt):
        self.check_panel.hide()
        self.reading.verticalScrollBar().setValue(0)
        self.pending = prompt
        self.progress.hide()
        self.cancel.setEnabled(True)
        self.clear_form()
        self.details_toggle.setChecked(False)
        from .install_settings import PROMPT as SETTINGS_PROMPT
        if (self.preparation and self.preparation[0][0] == '1. Developer Mode'
                and (prompt.label in (debloat.SELECT, SETTINGS_PROMPT) or prompt.label.startswith('Connect to check installed versions?'))):
            self.review_title = self.title.text()
            self.review_content = self.content.toHtml()
            self.preparation_return_step = self.current_step
            self.show_preparation(0, prompt)
            return
        if prompt.label == SSH_COMMAND_PROMPT and self.command == 'ssh-command':
            self.show_ssh_command_prompt()
            return
        if prompt.label == debloat.SELECT:
            self.show_debloat_selection()
            return
        if prompt.label == debloat.REVIEW:
            self.show_debloat_results()
            return
        if prompt.label == SETTINGS_PROMPT:
            self.show_install_settings()
            return
        if prompt.title == RETRY_STORAGE_PROMPT:
            self.title.setText(tr(RETRY_STORAGE_CHECK))
            self.subtitle.hide()
            self.button(RETRY_STORAGE_CHECK, lambda: self.submit('y'), True).setFocus()
            return
        if prompt.secret:
            developer = prompt.credential_type == 'developer'
            title = {'developer':'Developer Mode code (Passphrase)', 'key':'SSH key passphrase',
                     'root':'Root SSH password (hidden)'}.get(prompt.credential_type, prompt.title)
            self.title.setText(tr(title))
            self.subtitle.hide()
            if developer:
                cards = [self.instruction_card('Where to find the code', [
                    'Enter Passphrase: the six characters shown in Developer Mode on the TV. Match uppercase and lowercase letters.'], 'key-server'),
                    self.instruction_card('Important', [
                    'Use the code from the TV, not your LG account password. If no code is visible, turn on Key Server.'])]
            else:
                help_text = ('Enter the passphrase that unlocks your private SSH key file.' if prompt.credential_type == 'key'
                             else 'Enter your existing TV root SSH password. This was set when SSH access was configured.')
                cards = [self.instruction_card(title, [help_text])]
            self.content.setHtml('<p style="margin-bottom: 16px"></p>'.join(cards))
        label = QLabel(tr(title if prompt.secret else 'Connection check' if self.command != 'install' and prompt.label.startswith('Edition [') else prompt.title))
        label.setWordWrap(True)
        label.setObjectName('promptTitle')
        self.form_layout.addWidget(label)
        if prompt.label == 'Installer version choice: ':
            from .installer_update import DOWNLOAD, CONTINUE, RELEASES
            self.title.setText(tr('A newer installer is available'))
            self.subtitle.hide()
            def download_installer():
                QDesktopServices.openUrl(QUrl(RELEASES))
                self.submit('1')
            self.button(DOWNLOAD, download_installer, True).setFocus()
            self.button(CONTINUE, lambda: self.submit('2'))
        elif prompt.kind == 'confirm':
            from .recovery import SAVED_CONNECTION_PROMPT
            trust_prompt = prompt.label.startswith('Connect and remember this TV?')
            beta_prompt = prompt.label.startswith('Install experimental Root Beta?')
            if prompt.label.startswith(debloat.RESTORE_PROMPT):
                yes_label, no_label = debloat.RESTORE_LABEL, debloat.SKIP_RESTORE
            elif prompt.title == SAVED_CONNECTION_PROMPT:
                yes_label, no_label = 'Review recovery options', 'Cancel'
            elif prompt.title == 'Continue Root installation?':
                yes_label, no_label = 'Continue Root installation', 'Cancel'
            else:
                yes_label = 'Connect and remember' if trust_prompt else 'Try Root Beta' if beta_prompt else 'Continue'
                no_label = 'Cancel' if beta_prompt else 'No, go back / cancel this operation'
            yes = self.button(yes_label, lambda: self.submit('y'), prompt.default == 'y')
            no = self.button(no_label, lambda: self.submit('n'), prompt.default == 'n')
            (yes if prompt.default == 'y' else no).setFocus()
            if trust_prompt:
                self.button('Connection details', lambda: self.submit('?'))
        elif prompt.kind == 'choice' and prompt.label.startswith('Edition'):
            options = QFrame()
            options.setObjectName('runtimeChoiceList')
            row = QHBoxLayout(options)
            row.setContentsMargins(0, 0, 0, 0)
            row.setSpacing(12)
            group = QButtonGroup(options)
            for key, name, detail in prompt.options:
                card = EditionOption(tr(name), tr(detail), key)
                group.addButton(card)
                row.addWidget(card, 1)
                if key == prompt.default:
                    card.setChecked(True)
            self.form_layout.addWidget(options)
            proceed = self.button('Continue', lambda: self.submit(group.checkedButton().key), True)
            proceed.setEnabled(group.checkedButton() is not None)
            group.buttonToggled.connect(lambda: proceed.setEnabled(group.checkedButton() is not None))
            if group.checkedButton():
                group.checkedButton().setFocus()
        elif prompt.kind == 'choice' and prompt.label.startswith('Alternative edition'):
            # These choices lead to different setup paths. Keep both explanations
            # visible and give each action its own verb; cancellation is separate.
            label.hide()
            choices = QScrollArea()
            choices.setObjectName('runtimeChoices')
            choices.setFrameShape(QFrame.Shape.NoFrame)
            choices.setWidgetResizable(True)
            choices.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
            choices.setMinimumHeight(min(360, max(240, self.height()-440)))
            options = QWidget()
            rows = QVBoxLayout(options)
            rows.setContentsMargins(0, 0, 0, 0)
            rows.setSpacing(10)
            rows.setSizeConstraint(QLayout.SizeConstraint.SetMinimumSize)
            choices.setWidget(options)
            options.setAutoFillBackground(False)
            self.form_layout.addWidget(choices)
            for key, name, detail in prompt.options:
                if key == '0':
                    continue
                card = QFrame()
                card.setObjectName('runtimeChoice')
                column = QVBoxLayout(card)
                column.setContentsMargins(14, 12, 14, 12)
                column.setSpacing(8)
                column.setSizeConstraint(QLayout.SizeConstraint.SetMinimumSize)
                title = WrappedLabel(tr(name))
                title.setObjectName('promptTitle')
                column.addWidget(title)
                description = WrappedLabel(tr(detail))
                description.setObjectName('choiceDetail')
                column.addWidget(description)
                action = 'Try Root Beta' if name == BETA_TITLE else 'Install No-root'
                self.button(action, lambda _checked=False, selected=key: self.submit(selected), layout=column)
                rows.addWidget(card)
            cancel = self.button('Cancel', lambda: self.submit('0'))
            cancel.setDefault(True)
            cancel.setFocus()
        elif prompt.kind == 'choice':
            choices = Select()
            choices.setAccessibleName(tr(prompt.title))
            for key, name, detail in prompt.options:
                choices.addItem(tr(name) + (' — ' + tr(detail) if detail else ''), key)
                if key == prompt.default:
                    choices.setCurrentIndex(choices.count() - 1)
            self.form_layout.addWidget(choices)
            proceed = self.button('Continue', lambda: self.submit(choices.currentData()), True)
            if prompt.label == EXPLICIT_TV_CHOICE:
                choices.setPlaceholderText(tr('Choose a saved TV'))
                choices.setCurrentIndex(-1)
                proceed.setEnabled(False)
                choices.currentIndexChanged.connect(lambda index: proceed.setEnabled(index >= 0))
            choices.setFocus()
            if prompt.label.startswith('TV number'):
                # Saved-TV menus also use this label; retry is offered only for discovery.
                if any(name == 'Enter an IP address manually' for _, name, _ in prompt.options):
                    self.button('Search again', lambda: self.submit('r'))
        elif prompt.kind == 'ready':
            self.button('TV is on — check again', lambda: self.submit(''), True).setFocus()
        else:
            entry = QLineEdit()
            entry.setAccessibleName(label.text())
            label.setBuddy(entry)
            if prompt.secret:
                entry.setEchoMode(QLineEdit.EchoMode.Password)
            elif 'IP address' in prompt.label:
                entry.setPlaceholderText(tr('For example, 192.168.1.50'))
            self.form_layout.addWidget(entry)
            def submit_entry():
                value = entry.text()
                entry.clear()
                self.submit(value)
            entry.returnPressed.connect(submit_entry)
            self.button('Continue', submit_entry, True)
            if prompt.kind == 'file':
                def choose_file():
                    filename, _ = QFileDialog.getOpenFileName(self, tr('Choose your existing SSH private key'))
                    if filename:
                        entry.setText(filename)
                self.button('Choose key file…', choose_file)
            if 'IP address' in prompt.label:
                self.button('Search again', lambda: self.submit('r'))
                self.button('Help finding my TV', lambda: self.submit('?'))
            entry.setFocus()

    def show_ssh_command_prompt(self):
        profile = self.selected_profile
        root = profile['edition'] == 'root' or profile.get('connection') == 'root-ssh'
        user = 'root' if root else 'prisoner'
        self.title.setText(tr(SSH_COMMAND_PROMPT))
        self.badge.setText(tr('Diagnostics'))
        target = f"{user}@{profile['host']}:{profile['port']}"
        hint = tr('Review the command before running it.')
        if root:
            hint += ' ' + tr('This command can change the TV system.')
        self.subtitle.setText(target + '\n' + hint)
        self.subtitle.show()
        self.content.hide()
        self.details_toggle.hide()
        self.details.hide()
        editor = QPlainTextEdit()
        editor.setObjectName('sshCommandInput')
        editor.setAccessibleName(tr('SSH command'))
        editor.setTabChangesFocus(True)
        self.form_layout.addWidget(editor)
        run = self.button('Run', lambda: self.submit(editor.toPlainText()), True)
        run.setEnabled(False)
        editor.textChanged.connect(lambda: run.setEnabled(bool(editor.toPlainText().strip())))
        editor.setFocus()

    def show_ssh_command_result(self, result):
        self.set_error_state(bool(result.error) or result.exit_code not in (None, 0))
        self.title.setText(tr('SSH command result'))
        self.badge.setText(tr('Diagnostics'))
        target = self.subtitle.text().split('\n', 1)[0]
        self.subtitle.setText(target)
        self.content.hide()
        self.check_panel.hide()
        self.details_toggle.hide()
        self.details.hide()
        code = result.exit_code if result.exit_code is not None else tr('Unknown')
        lines = [tr('Exit code: {code}').format(code=code)]
        if result.error:
            lines.append(tr(result.error))
        if result.truncated:
            lines.append(tr('Output truncated at 256 KiB per stream.'))
        lines.extend(('', 'stdout', result.stdout, 'stderr', result.stderr))
        text = '\n'.join(lines)
        output = QPlainTextEdit()
        output.setObjectName('sshCommandOutput')
        output.setAccessibleName(tr('SSH command result'))
        output.setReadOnly(True)
        output.setPlainText(text)
        self.form_layout.addWidget(output)
        actions = QHBoxLayout()
        self.form_layout.addLayout(actions)
        copy = self.button('Copy output', lambda: QApplication.clipboard().setText(text), True, layout=actions)
        self.button('Back to start', self.home, layout=actions)
        copy.setFocus()

    def submit(self, value):
        self.content.show()
        if not self.pending:
            return
        ssh_command = self.command == 'ssh-command' and self.pending.label == SSH_COMMAND_PROMPT
        if ssh_command and value is not None:
            self.content.setPlainText(tr('Running SSH command…'))
        if self.pending.secret:
            self.content.clear()
            self.title.setText(tr('Connecting to your TV'))
        elif self.pending.title == RETRY_STORAGE_PROMPT:
            self.title.setText(tr('Review and install'))
        self.pending = None
        if self.check_results and not ssh_command:
            self.check_panel.show()
        self.clear_form()
        self.cancel.setEnabled(False)
        self.progress.show()
        self.channel.answer(value)

    def show_issue_draft(self):
        draft = diagnostics.load_issue_draft(self.report, self.command)
        dialog = QDialog(self)
        dialog.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        dialog.setWindowTitle(tr('Issue draft'))
        dialog.resize(640, 440)
        layout = QVBoxLayout(dialog)
        hint = WrappedLabel(tr('Copy the draft into the issue form. Only you can submit it.'))
        layout.addWidget(hint)

        title = QLineEdit(draft['title'])
        title.setMaxLength(256)
        title.setAccessibleName(tr('Issue title'))
        title_label = QLabel(tr('Issue title'))
        title_label.setBuddy(title)
        layout.addWidget(title_label)
        layout.addWidget(title)
        editor = QPlainTextEdit(draft['body'])
        editor.setAccessibleName(tr('Issue draft'))
        editor.setTabChangesFocus(True)
        layout.addWidget(editor)

        has_report = self.report is not None and self.report.is_file()
        instructions = ('Attach this diagnostic report' if has_report else
                        'Include the visible error when opening an issue.')
        layout.addWidget(WrappedLabel(tr(instructions)))
        fallback_message = 'Could not open the browser. Open the displayed link manually.'
        fallback = QWidget()
        fallback_layout = QVBoxLayout(fallback)
        fallback_layout.setContentsMargins(0, 0, 0, 0)
        fallback_layout.addWidget(WrappedLabel(tr(fallback_message)))
        link = QLineEdit()
        link.setAccessibleName(tr('Issue form link'))
        link.setReadOnly(True)
        fallback_layout.addWidget(link)
        layout.addWidget(fallback)
        fallback.hide()

        def open_form():
            url = diagnostics.issue_url(title.text().strip() or draft['title'])
            if not QDesktopServices.openUrl(QUrl(url)):
                link.setText(url)
                fallback.show()
                link.setFocus()
                link.selectAll()
            else:
                fallback.hide()

        actions = QHBoxLayout()
        layout.addLayout(actions)
        self.button('Copy draft', lambda: QApplication.clipboard().setText(editor.toPlainText()), layout=actions)
        if has_report:
            self.button('Save diagnostic report…', lambda: self.save_report(dialog), layout=actions)
        self.button('Open issue form', open_form, layout=actions)
        self.button('Cancel', dialog.reject, layout=actions)
        for button in dialog.findChildren(QPushButton):
            button.setAutoDefault(False)
        editor.setFocus()
        dialog.open()

    def show_reported_home_result(self):
        self.title.setText(tr('Home button diagnostics'))
        self.subtitle.setText(tr('Your Home-button result is already recorded. Review it below.'))
        self.badge.setText(self.title.text())

    def save_report(self, parent=None):
        filename, _ = QFileDialog.getSaveFileName(parent or self, tr('Save diagnostic report'), self.report.name, 'JSON (*.json)')
        if filename:
            try:
                if Path(filename).resolve() != self.report.resolve():
                    shutil.copyfile(self.report, filename)
            except OSError:
                self.error_dialog('Could not save report', 'Choose another folder and try again.')

    def closeEvent(self, event):
        if self.removal_watch is not None:
            self.finish_removal_watch('cancelled')
            event.ignore()
            return
        wallpaper_dialog = getattr(self, 'wallpaper_dialog', None)
        if wallpaper_dialog is not None and wallpaper_dialog.busy:
            event.ignore()
            if not getattr(self, '_wallpaper_closing', False):
                self._wallpaper_closing = True
                wallpaper_dialog.events.finished.connect(lambda _: self.close())
            wallpaper_dialog.close()
            return
        if self.running:
            event.ignore()
            if self.pending:
                self.submit(None)
            else:
                QMessageBox.information(self, tr('Operation in progress'), tr('Please wait for this step to finish. This keeps installation and recovery data consistent.'))
        else:
            event.accept()


def configure_appearance(app, fonts):
    for font in fonts.glob('Noto*.ttf'):
        QFontDatabase.addApplicationFont(str(font))
    QFont.insertSubstitutions(app.font().family(), ['Noto Sans', 'Noto Sans Devanagari', 'Noto Sans KR'])
    app.setStyle('Fusion')


def main():
    app = QApplication(sys.argv[:1])
    configure_appearance(app, cli.payload_dir() / 'fonts')
    app.setApplicationName('Clean Your TV')
    app.setOrganizationName('CleanYourTV')
    app.setWindowIcon(QIcon(str(cli.payload_dir() / 'installer.png')))
    window = Wizard()
    window.show()
    if '--smoke-test' in sys.argv:
        QTimer.singleShot(200, app.quit)
    return app.exec()


if __name__ == '__main__':
    raise SystemExit(main())
