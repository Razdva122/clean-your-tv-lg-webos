"""Deterministic IPK creation and data-only launcher personalization."""
import gzip
import hashlib
import io
import json
import re
import unicodedata
from pathlib import Path, PurePosixPath
import tarfile

ROOT_APP = 'com.cleanyourtv.root.preview'
SCREENSAVER_APP = 'com.cleanyourtv.screensaver'
SCREENSAVER_IPK = 'screensaver.ipk'
# webOS pkgverifier rejects epoch-zero tar dates. Fixed 2024-01-01 keeps builds reproducible.
IPK_MTIME = 1704067200


def safe_name(name):
    path = PurePosixPath(name)
    if not name or path.is_absolute() or str(path) != name or '..' in path.parts or '\\' in name or '\x00' in name:
        raise ValueError('Unsafe package path')
    return name


def ar(parts):
    result = bytearray(b'!<arch>\n')
    for name, data in parts.items():
        result.extend(f'{name + "/":<16}{0:<12}{0:<6}{0:<6}{"100644":<8}{len(data):<10}`\n'.encode())
        result.extend(data)
        if len(data) % 2:
            result.extend(b'\n')
    return bytes(result)


def read_ar(data):
    if data[:8] != b'!<arch>\n':
        raise ValueError('Not an IPK archive')
    result, offset = {}, 8
    while offset < len(data):
        header = data[offset:offset + 60]
        if len(header) != 60 or header[58:] != b'`\n':
            raise ValueError('Invalid IPK member')
        size = int(header[48:58])
        name = header[:16].decode().strip().rstrip('/')
        content = data[offset + 60:offset + 60 + size]
        if size < 0 or len(content) != size or name in result:
            raise ValueError('Invalid IPK member size or duplicate')
        result[name] = content
        offset += 60 + size + size % 2
    return result


def tgz(files, executable=(), helper_state=False, directories=True, shared_directories=False):
    raw = io.BytesIO()
    dirs = set()
    for name in files:
        safe_name(name)
        dirs.update(str(p) for p in PurePosixPath(name).parents if str(p) != '.' and
                    (shared_directories or p.parts[:2] != ('usr','palm') or len(p.parts) >= 4))
    # Root archives retain owned leaves only; No-root opts into SDK parents for opkg.
    if not shared_directories:
        dirs.discard('usr')
    with tarfile.open(fileobj=raw, mode='w', format=tarfile.USTAR_FORMAT) as archive:
        for name in sorted(dirs) if directories else ():
            entry = tarfile.TarInfo(name)
            entry.mtime = IPK_MTIME
            entry.type, entry.mode = tarfile.DIRTYPE, 0o755
            if helper_state and name in ('usr/palm/applications/com.local.nativehome/state', 'usr/palm/services/com.local.nativehome.service/state'):
                entry.uid, entry.gid, entry.mode = 5999, 5000, 0o770
                entry.uname, entry.gname = 'prisoner', 'jailer'
            if name in ('usr/palm/services/com.gathin.tvhome.renewal/state',
                        'usr/palm/services/com.gathin.tvhome.renewal/state/home-control'):
                # Native controller and jailed JS service have distinct UIDs.
                # setgid keeps both sides' files in the shared jailer group.
                entry.uid, entry.gid, entry.mode = 5999, 5000, 0o2770
                entry.uname, entry.gname = 'prisoner', 'jailer'
            archive.addfile(entry)
        for name, data in sorted(files.items()):
            entry = tarfile.TarInfo(name)
            entry.mtime = IPK_MTIME
            entry.size, entry.mode = len(data), 0o755 if name in executable else 0o644
            archive.addfile(entry, io.BytesIO(data))
    compressed = io.BytesIO()
    # GzipFile keeps the OS byte canonical across Python/zlib build hosts.
    with gzip.GzipFile(filename='', fileobj=compressed, mode='wb', compresslevel=9, mtime=0) as packed:
        packed.write(raw.getvalue())
    return compressed.getvalue()


def ipk(app, version, files, executable=(), helper_state=False, architecture='all', shared_directories=False):
    control = f'Package: {app}\nVersion: {version}\nArchitecture: {architecture}\nMaintainer: Clean Your TV\nDescription: Clean Your TV\n'
    return ar({'debian-binary': b'2.0\n', 'control.tar.gz': tgz({'control': control.encode()}),
               'data.tar.gz': tgz(files, executable, helper_state, shared_directories=shared_directories)})


def data_files(data):
    with tarfile.open(fileobj=io.BytesIO(read_ar(data)['data.tar.gz']), mode='r:gz') as archive:
        result = {}
        for member in archive:
            if member.isdir():
                continue
            safe_name(member.name)
            if not member.isfile() or member.size > 16 * 1024 * 1024:
                raise ValueError('Unsupported package member')
            result[member.name] = archive.extractfile(member).read()
        return result


def verify_root_rollback_format(data):
    """Accept file-only history and secure own-leaf directory entries."""
    parts=read_ar(data)
    roots=('usr/palm/applications/'+ROOT_APP,'usr/palm/services/'+ROOT_APP+'.service','usr/palm/packages/'+ROOT_APP)
    for name in ('control.tar.gz','data.tar.gz'):
        seen=set();dirs=set();files=set()
        with tarfile.open(fileobj=io.BytesIO(parts[name]),mode='r:gz') as archive:
            for member in archive:
                safe_name(member.name)
                if member.name in seen:raise ValueError('Root rollback package has duplicate archive entries')
                seen.add(member.name)
                if member.isdir():
                    if (member.size or member.mode!=0o755 or member.uid!=0 or member.gid!=0
                            or not any(member.name==root or member.name.startswith(root+'/') for root in roots)):
                        raise ValueError('Root rollback package has unsupported archive entries. Use a corrected installer build.')
                    dirs.add(member.name)
                elif member.isfile():files.add(member.name)
                else:raise ValueError('Root rollback package has unsupported archive entries. Use a corrected installer build.')
        if dirs-{str(parent) for file in files for parent in PurePosixPath(file).parents}:raise ValueError('Root rollback package has foreign directories')


def inventory_script(inventory):
    if not isinstance(inventory, dict) or not isinstance(inventory.get('apps'), list) or not inventory['apps']:
        raise ValueError('No usable apps were read from the TV. Installation stopped.')
    if len(inventory['apps']) > 200 or len(inventory.get('inputs', [])) > 100:
        raise ValueError('TV inventory is too large')
    data = {key: value for key, value in inventory.items() if key != 'fallbackIcon'}
    script = ('window.TV_APPS = ' + json.dumps(data, ensure_ascii=True) + ';\n').encode()
    if inventory.get('fallbackIcon'):
        script += ('window.CYTVPackagedIconFallback = ' + json.dumps(inventory['fallbackIcon']) + ';\n').encode()
    if len(script) > 16 * 1024 * 1024:
        raise ValueError('TV inventory exceeds the 16 MiB package limit')
    return script


def normalize_tv_name(value):
    if not isinstance(value, str):
        raise ValueError('Home screen name must be text.')
    name = unicodedata.normalize('NFC', value.strip()) or 'Home'
    if len(name) > 48 or re.search(r'[\u0000-\u001f\u007f-\u009f\u00ad\u061c\u200b-\u200f\u2028-\u202e\u2060-\u206f\ufeff\ud800-\udfff]', name):
        raise ValueError('Home screen name must contain at most 48 characters, without control characters.')
    return name


def personalize(data, app, inventory, *, no_root_connection=None):
    parts = read_ar(data)
    files = data_files(data)
    # Preserve execution from the validated regular files; tgz normalizes all
    # permissions to 0755/0644, without retaining setuid or other special bits.
    with tarfile.open(fileobj=io.BytesIO(parts['data.tar.gz']), mode='r:gz') as archive:
        executable = {member.name for member in archive if member.isfile() and member.mode & 0o111}
    script = inventory_script(inventory)
    if no_root_connection is not None:
        script += ('window.CYTVNoRootConnection = ' + json.dumps(no_root_connection) + ';\n').encode()
    files['usr/palm/applications/' + app + '/apps.js'] = script
    parts['data.tar.gz'] = tgz(files, executable=executable, directories=True,
                             shared_directories=app == 'com.gathin.tvhome')
    return ar(parts), files


def personalize_root(bundle, inventory):
    bundle = Path(bundle)
    manifest = json.loads((bundle / 'bundle.json').read_text())
    for name, digest in manifest['files'].items():
        if hashlib.sha256((bundle / safe_name(name)).read_bytes()).hexdigest() != digest:
            raise ValueError('Root bundle integrity mismatch')
    name = manifest['package']
    data, files = personalize((bundle / name).read_bytes(), ROOT_APP, inventory)
    (bundle / name).write_bytes(data)
    release = json.loads((bundle / 'release.json').read_text())
    release['files'] = {n: hashlib.sha256(b).hexdigest() for n, b in sorted(files.items())}
    (bundle / 'release.json').write_text(json.dumps(release), encoding='utf-8')
    (bundle / 'SHA256SUMS').write_text(hashlib.sha256(data).hexdigest() + '  ' + name + '\n', encoding='utf-8')
    manifest['files'] = {n: hashlib.sha256((bundle / safe_name(n)).read_bytes()).hexdigest() for n in manifest['files']}
    (bundle / 'bundle.json').write_text(json.dumps(manifest), encoding='utf-8')


def screensaver_payload(root, manifest):
    """Read and validate the optional companion from an authenticated payload."""
    name = manifest.get('screensaver')
    version = manifest.get('screensaver_version')
    if 'screensaver' not in manifest and 'screensaver_version' not in manifest:
        return None
    if name != SCREENSAVER_IPK or not isinstance(version, str) or not re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+', version):
        raise ValueError('Invalid embedded screensaver declaration')
    path = Path(root) / name
    if path.is_symlink():
        raise ValueError('Indirect embedded screensaver package')
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != manifest['files'].get(name):
        raise ValueError('Embedded screensaver package integrity mismatch')
    files = data_files(raw)
    app = 'usr/palm/applications/' + SCREENSAVER_APP + '/'
    package = 'usr/palm/packages/' + SCREENSAVER_APP + '/packageinfo.json'
    if not all(entry == package or entry.startswith(app) for entry in files):
        raise ValueError('Unexpected embedded screensaver paths')
    info = json.loads(files.get(app + 'appinfo.json', b'null'))
    metadata = json.loads(files.get(package, b'null'))
    if (not isinstance(info, dict) or info.get('id') != SCREENSAVER_APP or info.get('version') != version
            or info.get('type') != 'web' or info.get('defaultWindowType') != 'popup'
            or info.get('visible') is not False or info.get('requiredACG')
            or info.get('privilegedJail')
            or metadata != {'id': SCREENSAVER_APP, 'app': SCREENSAVER_APP, 'version': version, 'services': []}):
        raise ValueError('Embedded screensaver identity or version mismatch')
    return raw, version


def _payload_manifest(root):
    manifest = json.loads((root / 'payload.json').read_text())
    if not isinstance(manifest, dict) or not isinstance(manifest.get('files'), dict):
        raise ValueError('Invalid embedded payload manifest')
    if not manifest['files']:
        raise ValueError('Empty embedded payload')
    return manifest


def _payload_file(root, name):
    path = root / safe_name(name)
    if not path.is_file() or path.is_symlink():
        raise ValueError('Embedded payload integrity mismatch')
    return path


def check_payload_files(root):
    """Check availability at desktop startup, before reading package bytes."""
    root = Path(root)
    for name in _payload_manifest(root)['files']:
        _payload_file(root, name)


def verify_payload(root):
    root = Path(root)
    manifest = _payload_manifest(root)
    for name, digest in manifest['files'].items():
        path = _payload_file(root, name)
        raw = path.read_bytes()
        if hashlib.sha256(raw).hexdigest() != digest:
            raise ValueError('Embedded payload integrity mismatch')
        # Integrity alone cannot detect CRLF introduced before the build hashes.
        files = data_files(raw) if name.endswith('.ipk') else {name: raw}
        for script, data in files.items():
            if script.endswith('.sh') and b'\r' in data:
                raise ValueError('POSIX script must use LF line endings: ' + name + ': ' + script)
    screensaver_payload(root, manifest)
    return manifest
