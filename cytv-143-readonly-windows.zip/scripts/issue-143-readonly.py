#!/usr/bin/env python3
"""Collect a read-only report for the saved Root removal in issue #143."""
import json
from pathlib import Path
import re
import sys


SCRIPT = Path(__file__).resolve()
sys.path.insert(0, str(SCRIPT.parents[1]))
REPORT = 'cytv-143-readonly.json'

STATUSES = ('read', 'record-missing', 'record-mismatch', 'record-changed',
            'record-unavailable', 'root-required')
STAGES = ('requested', 'original-writers-fenced', 'controls-restored',
          'package-removal', 'private-cleanup', 'restart-required', 'verified-clean')
REPLIES = ('timeout', 'client-error', 'invalid-reply', 'negative-reply')
CHOICES = {
    'stage': STAGES,
    'sam': REPLIES + ('lg-home', 'live-tv', 'cytv', 'other-app', 'empty-app'),
    'surfaces': REPLIES + ('no-stock-home', 'other-surfaces', 'stock-home-card',
                           'stock-home-window', 'stock-home-and-sam-card', 'stock-home-and-live-tv-card'),
    'routing_evidence': ('present', 'absent'),
    'backup_routing_evidence': ('present', 'absent', 'missing'),
    'backend': ('keyfilter', 'legacy-native', 'other', 'absent'),
    'restore_check': ('stock-foreground-unverified', 'stock-surface-unverified',
                      'stock-routing-unverified', 'native-stop-unverified'),
}


def shareable(value):
    """Revalidate every report field on the PC, including replies from the TV."""
    if not isinstance(value, dict) or value.get('status') not in STATUSES:
        return {'status': 'unexpected-reply'}
    report = {'status': value['status']}
    if report['status'] == 'read':
        for name, choices in CHOICES.items():
            if name in value:
                report[name] = value[name] if value[name] in choices else 'unknown'
        for name in ('never_applied', 'profileless'):
            report[name] = value.get(name) if type(value.get(name)) is bool else None
    return report


def saved_removal():
    from cytv.state import Store

    store = Store()
    matches = []
    for profile in store.profiles():
        if profile.get('edition') != 'root':
            continue
        directory = store.device_path(profile)
        raw, pending = store._read_operation(directory / 'operation.json', require_access=True)
        if (pending and pending.get('action') == 'uninstall'
                and pending.get('full_project') is True
                and pending.get('recovery_protocol') == 'clean-removal-v1'
                and 'root_reinstall_payload' not in pending):
            matches.append((profile, directory, raw, pending))
    return matches[0] if len(matches) == 1 else None


def observe():
    from cytv.root_passive import READERS
    from cytv.transport import SSH, inspection_secret

    try:
        saved = saved_removal()
        if saved is None:
            return {'status': 'one-saved-root-removal-required'}
        profile, directory, raw, pending = saved
        binding = {
            'goal': pending.get('removal_target_intent', pending.get('removal_operation')),
            'target': pending.get('removal_target_operation'),
            'lease': pending.get('removal_target_lease'),
        }
        if (binding['goal'] is None or any(
                value is not None and (not isinstance(value, str) or not re.fullmatch('[0-9a-f]{32}', value))
                for value in binding.values())):
            return {'status': 'saved-removal-invalid'}
        connection_paths = [directory / name for name in ('profile.json', 'known_hosts', 'operation.json')]
        if any(path.is_symlink() for path in connection_paths):
            return {'status': 'saved-connection-unavailable'}
        before = [path.read_bytes() for path in connection_paths]
        if before[-1] != raw or not before[1]:
            return {'status': 'saved-connection-unavailable'}
        source = SCRIPT.with_suffix('.js').read_text(encoding='utf-8')
    except (OSError, ValueError, RuntimeError):
        return {'status': 'saved-connection-unavailable'}

    try:
        remote = SSH.connect(profile, directory, inspection_secret, lambda *_: False, persist=False)
    except Exception:
        return {'status': 'ssh-connection-failed'}
    try:
        program = READERS + 'var expected = ' + json.dumps(binding) + ';\n' + source
        command = 'env -u NODE_OPTIONS -u NODE_PATH /usr/bin/node'
        # Stop collecting at the first oversized or invalid result.
        channel = remote._command_channel(command, program.encode('utf-8'))
        try:
            output = bytearray()
            for chunk in remote.chunks(channel, timeout=25):
                output.extend(chunk)
                if len(output) > 4096:
                    return {'status': 'unexpected-reply'}
        finally:
            channel.close()
        if [path.read_bytes() for path in connection_paths] != before:
            return {'status': 'saved-connection-changed'}
        return shareable(json.loads(output))
    except Exception:
        return {'status': 'observation-unavailable'}
    finally:
        remote.close()


def main():
    if len(sys.argv) != 1:
        print(__doc__, file=sys.stderr)
        return 2
    try:
        with open(REPORT, 'x', encoding='utf-8') as stream:
            try:
                result = observe()
            except KeyboardInterrupt:
                result = {'status': 'cancelled'}
            except ImportError:
                result = {'status': 'dependency-unavailable'}
            json.dump({'schema': 1, 'issue': 143, **result}, stream, indent=2)
            stream.write('\n')
    except FileExistsError:
        print(f'{REPORT} already exists. Keep it and run in a new folder.', file=sys.stderr)
        return 2
    print(f'{REPORT} ({result["status"]})')
    return 0 if result['status'] == 'read' else 1


if __name__ == '__main__':
    raise SystemExit(main())
