// Appended inside cytv.root_passive.READERS. Runs from SSH stdin on stock Node.
const childProcess = require('child_process');
const base = '/var/lib/clean-your-tv-installation';
const root = '/var/lib/clean-your-tv-root';
const stock = 'com.webos.app.home';
const liveTV = 'com.webos.app.livetv';
const card = '_WEBOS_WINDOW_TYPE_CARD';
const home = '_WEBOS_WINDOW_TYPE_HOME';
const markers = [
  'profile-trial.json', 'persistent-intent.json', 'persistent-binding.json', 'boot-continuation.json',
  'profile-candidate.stage', 'home-backend.json', 'c1-gate', 'c1-keyfilter'
];
const restoreChecks = [
  'stock-foreground-unverified', 'stock-surface-unverified', 'stock-routing-unverified', 'native-stop-unverified'
];

function exists(path) {
  try {
    fs.lstatSync(path);
    return true;
  } catch (error) {
    if (error.code === 'ENOENT') return false;
    throw error;
  }
}

function snapshot() {
  const leaseRaw = read(base + '/operation.json', 65536);
  const lease = parse(leaseRaw);
  const target = typeof lease.journal === 'string' && /^product-([a-f0-9]{32})[.]json$/.exec(lease.journal);
  if (lease.schema !== 1 || lease.owner !== 'clean-removal' || lease.terminal !== false ||
      typeof lease.id !== 'string' || !/^[a-f0-9]{32}$/.test(lease.id) || !target ||
      (expected.target !== null && target[1] !== expected.target) ||
      (expected.lease !== null && lease.id !== expected.lease)) fail('record-mismatch');

  const removalRaw = read(base + '/clean-removal-' + target[1] + '.json', 4 * 1024 * 1024);
  const removal = parse(removalRaw);
  if (removal.schema !== 1 || removal.protocol !== 'clean-removal-v1' ||
      removal.operation !== target[1] || removal.lease !== lease.id ||
      removal.removal !== expected.goal || removal.stage !== lease.stage ||
      removal.stage !== 'original-writers-fenced') fail('record-mismatch');

  const backupRaw = optional(base + '/routing-backup-' + target[1] + '.json', 4 * 1024 * 1024);
  const backup = backupRaw && parse(backupRaw);
  if (backupRaw && (!backup || typeof backup !== 'object' || Array.isArray(backup))) fail('unsafe');
  if (exists(root)) directory(root);
  const present = markers.filter(name => exists(root + '/' + name));
  const override = exists('/var/webos-profile/override/clean-your-tv-root.json');
  const backendRaw = optional(root + '/home-backend.json', 65536);
  const backend = backendRaw && parse(backendRaw);
  const failure = removal.last_failure || removal.failure || {};
  const check = (failure.cleanup_probe || {}).restore_check;
  return {
    hashes: [leaseRaw, removalRaw, backupRaw, backendRaw].map(entry => entry && sha(entry.bytes)),
    markers: [present, override],
    report: {
      status: 'read',
      stage: removal.stage,
      never_applied: typeof removal.routing_never_applied === 'boolean' ? removal.routing_never_applied : null,
      profileless: typeof removal.profileless_cleanup_eligible === 'boolean' ? removal.profileless_cleanup_eligible : null,
      routing_evidence: present.length || override ? 'present' : 'absent',
      backup_routing_evidence: !backup ? 'missing' : Object.keys(backup).some(
        name => markers.indexOf(name.split('/')[0]) !== -1) ? 'present' : 'absent',
      backend: !backendRaw ? 'absent' : !backend || backend.backend !== 'c1-native-gate' ? 'other' :
        backend.schema === 3 ? 'keyfilter' : [1, 2].indexOf(backend.schema) !== -1 ? 'legacy-native' : 'other',
      restore_check: restoreChecks.indexOf(check) !== -1 ? check : undefined
    }
  };
}

function foreground(service) {
  return new Promise(resolve => {
    // Keep the child's stdin open as the TV runtime does. Some older clients
    // exit before printing their reply when stdin reaches EOF.
    const child = childProcess.spawn('/usr/bin/luna-send',
      ['-n', '1', 'luna://' + service + '/getForegroundAppInfo', '{}'],
      {stdio: ['pipe', 'pipe', 'ignore']});
    let size = 0;
    let chunks = [];
    let done = false;
    const timer = setTimeout(() => finish('timeout'), 5000);
    function finish(category, value) {
      if (done) return;
      done = true;
      clearTimeout(timer);
      child.kill();
      child.stdin.destroy();
      child.stdout.destroy();
      resolve({category, value});
    }
    child.on('error', () => finish('client-error'));
    child.stdin.on('error', () => {});
    child.stdout.on('error', () => finish('client-error'));
    child.stdout.on('data', chunk => {
      size += chunk.length;
      if (size > 65536) return finish('invalid-reply');
      chunks.push(chunk);
      let value;
      try {
        value = JSON.parse(Buffer.concat(chunks, size).toString('utf8'));
      } catch (_) {
        return;
      }
      if (!value || typeof value !== 'object' || Array.isArray(value)) return finish('invalid-reply');
      if (value.returnValue === false) return finish('negative-reply');
      if (value.returnValue !== true) return finish('invalid-reply');
      finish(null, value);
    });
    child.on('close', code => finish(code === 0 || size ? 'invalid-reply' : 'client-error'));
  });
}

function appCategory(reply) {
  if (reply.category) return reply.category;
  const id = reply.value.appId;
  if (typeof id !== 'string') return 'invalid-reply';
  if (!id) return 'empty-app';
  if (id === stock) return 'lg-home';
  if (id === liveTV) return 'live-tv';
  if (/^com[.]cleanyourtv[.]|^com[.]local[.]nativehome$|^com[.]gathin[.]tvhome$/.test(id)) return 'cytv';
  return 'other-app';
}

function surfaceCategory(reply, sam, samCategory) {
  if (reply.category) return reply.category;
  const rows = reply.value.foregroundAppInfo;
  if (!Array.isArray(rows) || rows.length > 128) return 'invalid-reply';
  const stockVisible = rows.filter(row => row && row.appId === stock &&
    (row.windowType === card || row.windowType === home) && row.visible !== false);
  if (!stockVisible.length) return 'no-stock-home';
  if (rows.some(row => !row || (row.displayId !== undefined && row.displayId !== 0) ||
      (row.visible !== undefined && typeof row.visible !== 'boolean') ||
      (row.pip !== undefined && row.pip !== false) ||
      (row.multiview !== undefined && row.multiview !== false) ||
      (row.viewType !== undefined && row.viewType !== 'normal'))) return 'other-surfaces';
  const behind = rows.filter(row => row.appId !== stock || (row.windowType !== home && row.windowType !== card));
  const homeWindow = stockVisible.some(row => row.windowType === home);
  if (!behind.length) return homeWindow ? 'stock-home-window' : 'stock-home-card';
  if (!homeWindow || behind.length !== 1 || behind[0].windowType !== card) return 'other-surfaces';
  if (behind[0].appId === liveTV) return 'stock-home-and-live-tv-card';
  if (samCategory === 'other-app' && behind[0].appId === sam) return 'stock-home-and-sam-card';
  return 'other-surfaces';
}

async function observe() {
  if (process.getuid() !== 0) return {status: 'root-required'};
  const before = snapshot();
  const sam = await foreground('com.webos.applicationManager');
  const surfaces = await foreground('com.webos.surfacemanager');
  const after = snapshot();
  if (JSON.stringify(before) !== JSON.stringify(after)) return {status: 'record-changed'};
  const samCategory = appCategory(sam);
  return Object.assign(before.report, {
    sam: samCategory,
    surfaces: surfaceCategory(surfaces, sam.value && sam.value.appId, samCategory)
  });
}

observe().then(result => console.log(JSON.stringify(result)), error => {
  const status = error.code === 'ENOENT' ? 'record-missing' :
    error.category === 'record-mismatch' ? 'record-mismatch' : 'record-unavailable';
  console.log(JSON.stringify({status}));
});
}());
